"""Load the exact existing provider and predecessor implementation sources."""
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import stat
import sys

PROVIDER_PINS = "15e27eea749e5d08f7d41256515b078f256c89fed5c49647c09dc99b99406eae"
PROBE_PINS = "233f9658ccd015e2c9e7c268723963ed3713dbb2fc4a552f65d2b52a13288cfd"
PREDECESSOR_RECEIPT = "e201a2bf6c56f57498146dfcdfcb19e6fcda4f21110842f5ed3908d09f5fd66e"
V101_SOURCE_PINS = "2dad77ee9f0c2a9ad09d084c92656107e081df8bd8224cafbdf8d89bf8a76f4e"
V101_TEST_RECEIPT = "d36f26bca85b73b4e713e1e826faf6b9463b854245a76ad832f260af15caac4f"
CASE = "first-grant-build-linux-sqlite-300-associations-debug-repetition-1"
CELL = "linux-amd64/sqlite/300/all_model_queries_and_associations/debug/1"
STRICT_BYTES = 2000000000


def need(value, message):
    if not value:
        raise RuntimeError(message)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def parse(raw):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            need(key not in result, "Unique JSON object keys required")
            result[key] = value
        return result
    def finite(value):
        raise RuntimeError("Finite JSON values required: " + value)
    return json.loads(raw, object_pairs_hook=unique, parse_constant=finite)


def physical(path, maximum):
    path = Path(path)
    need(path.is_file() and not path.is_symlink() and path.absolute() == path.resolve()
         and path.stat().st_size <= maximum,
         "A bounded physical evidence/source file is required: " + str(path))
    before = path.stat()
    raw = path.read_bytes()
    after = path.stat()
    need((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
         == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns),
         "Physical file identity remains stable during observation")
    return raw


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def verify_manifest(folder, expected, filename="SOURCE_PINS.json"):
    path = folder / filename
    need(digest(path) == expected, "Independently supplied exact source manifest required")
    manifest = parse(physical(path, 256 * 1024))
    rows = manifest["files"]
    need(type(rows) is list and len({row["path"] for row in rows}) == len(rows),
         "Complete unique source path roster required")
    for row in rows:
        relative = Path(row["path"])
        need(not relative.is_absolute() and ".." not in relative.parts, "Canonical relative source paths required")
        selected = folder / relative
        need(selected.resolve() == selected and selected.stat().st_size == row["bytes"]
             and stat.S_IMODE(selected.stat().st_mode) == row["mode"]
             and digest(selected) == row["sha256"], "Exact reviewed source member differs: " + str(relative))
    return manifest


def admit(here, source_pins, provider_root):
    here, provider_root = Path(here).resolve(), Path(provider_root).resolve()
    manifest = verify_manifest(here, source_pins)
    need(manifest["format"] == "atlas-first-grant-build-external-case-sources-v1"
         and manifest["predecessor_receipt_sha256"] == PREDECESSOR_RECEIPT
         and manifest["preserved_v101_source_pins_sha256"] == V101_SOURCE_PINS
         and manifest["preserved_v101_test_receipt_sha256"] == V101_TEST_RECEIPT
         and digest(here / "ANCESTOR_SOURCE_ROSTER.json") == manifest["ancestor_roster_sha256"],
         "Exact successor case and preserved predecessor required")
    provider = provider_root / "tools/installation_provenance"
    probe_root = provider_root / "tools/whole_build_memory"
    verify_manifest(provider, PROVIDER_PINS)
    verify_manifest(probe_root, PROBE_PINS)
    budget = load("cgroup_budget", provider / "cgroup_budget.py")
    terminal = load("atlas_existing_terminal_reader", provider / "verify_terminal.py")
    probe = load("atlas_existing_whole_build_probe", probe_root / "probe.py")
    worker = load("atlas_exact_v100_build_worker", here / "vendor_v100/build_in_cgroup.py")
    observation = load("atlas_exact_v100_observation_reader", here / "vendor_v100/validate_observation.py")
    return budget, terminal, probe, worker, observation


def read_json(path, terminal, maximum=1024 * 1024):
    raw = physical(path, maximum)
    strict = parse(raw)
    need(terminal.read_json(path, maximum) == strict, "Existing bounded reader and strict JSON perimeter agree")
    return strict


def save(path, value):
    raw = (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("xb") as stream:
        stream.write(raw)
        stream.flush()
        import os
        os.fsync(stream.fileno())
    temporary.replace(path)


def verify_inner_bounds(report, profile_sha256, preparation_sha256, budget):
    need(report["profile_sha256"] == profile_sha256 and report["preparation_sha256"] == preparation_sha256,
         "The inner observation must bind the exact reviewed profile and preparation")
    commands = report["commands"]
    need(type(commands) is list and len(commands) == 4, "All four original complete build/runtime commands required")
    for index, row in enumerate(commands):
        elapsed = row.get("elapsed_seconds")
        maximum = 900 if index == 0 else 120
        need(type(elapsed) in (int, float) and math.isfinite(elapsed) and 0 <= elapsed <= maximum,
             "Actual measured command duration exceeds its original bounded interval")
        sizes = [row[channel]["bytes"] for channel in ("stdout", "stderr")]
        need(all(type(value) is int and value >= 0 for value in sizes) and sum(sizes) <= 8 * 2**20,
             "Complete combined stdout/stderr must fit the original8MiB output budget")
    need(type(commands[0].get("wait4_maximum_rss_bytes")) is int
         and 0 < commands[0]["wait4_maximum_rss_bytes"] < STRICT_BYTES,
         "The worker's actual compiler RSS upper bound must stay strictly below2000000000bytes")
    limits = budget.Limits(STRICT_BYTES, 4096)
    for value in (report["before"], report["build_window"]["before"], report["build_window"]["after"],
                  report["final_raw_kernel_snapshot"]):
        budget.verify_snapshot(budget.Snapshot(**value), limits)
    budget.compare_snapshots(budget.Snapshot(**report["build_window"]["before"]),
                             budget.Snapshot(**report["build_window"]["after"]), limits)
    need(report["before"] == report["build_window"]["before"], "The complete build window retains its exact entry snapshot")
    budget.compare_snapshots(budget.Snapshot(**report["build_window"]["after"]),
                             budget.Snapshot(**report["final_raw_kernel_snapshot"]), limits)
