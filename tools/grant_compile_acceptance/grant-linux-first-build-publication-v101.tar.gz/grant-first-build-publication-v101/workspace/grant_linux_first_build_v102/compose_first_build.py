#!/usr/bin/env python3
"""Extend the exact predecessor dispatch with the same-process lifetime wrapper."""
import argparse
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from source_admission import CASE, admit, digest, load, need, parse, save


def compose(here, roots, profile, token, source_pins):
    legacy = load("atlas_exact_v100_dispatch", here / "vendor_v100/compose_dispatch.py")
    value = legacy.commands(roots, profile, token)
    argv = value["create"]
    index = argv.index(value["image"])
    argv[index:index] = ["--label", "org.amberframework.atlas.case=" + CASE]
    index = argv.index("/proposal/build_in_cgroup.py")
    argv[index] = "/proposal/run_first_grant_build.py"
    argv[index + 1:index + 1] = ["--source-pins-sha256", source_pins]
    value.update(format="atlas-grant-linux-first-build-dispatch-plan-v2", case=CASE,
                 source_pins_sha256=source_pins, lifetime_wrapper_preserves_pid1=True)
    return value


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-pins-sha256", required=True)
    parser.add_argument("--provider-root", type=Path, required=True)
    parser.add_argument("--profile", type=Path, required=True)
    parser.add_argument("--profile-sha256", required=True)
    parser.add_argument("--preparation-sha256", required=True)
    parser.add_argument("--roots", type=Path, required=True)
    parser.add_argument("--token", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    admit(here, args.source_pins_sha256, args.provider_root)
    need(digest(args.profile) == args.profile_sha256, "Exact independently reviewed native profile required")
    roots = parse(args.roots.read_bytes())
    roots.update(profile_sha256=args.profile_sha256, preparation_sha256=args.preparation_sha256)
    save(args.output, compose(here, roots, parse(args.profile.read_bytes()), args.token, args.source_pins_sha256))


if __name__ == "__main__":
    main()
