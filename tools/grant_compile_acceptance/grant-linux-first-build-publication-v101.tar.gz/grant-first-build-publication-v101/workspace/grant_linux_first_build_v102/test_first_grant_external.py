"""Clearly synthetic input controls for the real separately named reader/CLI."""
import copy
import hashlib
import json
from pathlib import Path
import sys
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
V100 = WORK / "grant_linux_first_build_v100"
PROVIDER = WORK / "linux_whole_build_ci_v100/checkout"
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(V100))
sys.path.insert(0, str(WORK / "grant/scripts"))
from source_admission import CASE, CELL, PROVIDER_PINS, admit, digest, load, save, verify_inner_bounds
import run_first_grant_build as wrapper
import verify_first_grant_build as reader
from compose_first_build import compose


def reference(path):
    return {"path": path.name, "bytes": path.stat().st_size, "sha256": digest(path)}


class SyntheticExternalControls(unittest.TestCase):
    def setUp(self):
        self.pins = digest(HERE / "SOURCE_PINS.json")
        self.budget, self.terminal, self.probe, self.worker, self.observation = admit(HERE, self.pins, PROVIDER)
        legacy = load("atlas_preserved_v100_source_tests", V100 / "test_first_build.py")
        self.legacy = legacy.FirstBuildControls()
        self.legacy.setUp()
        self.addCleanup(self.legacy.tearDown)
        self.root = self.legacy.root.resolve()
        build = self.root / "build"
        build.mkdir()
        for path in list(self.root.iterdir()):
            if path != build:
                path.rename(build / path.name)
        self.preparation = self.legacy.preparation
        self.profile = {"format": "atlas-grant-linux-build-integration-profile-v1", "platform": "linux-amd64",
            "ordinary_alpha_installation_ready": True, "readiness_receipt_sha256": "a" * 64,
            "runtime_projection_reviewed": True, "compiler_wrapper": self.legacy.profile["compiler_wrapper"],
            "compiler_backend": "/SYNTHETIC/alpha-backend", "compiler_environment": {"PATH": "/usr/bin:/bin"},
            "files": [{"path": value, "sha256": "a" * 64} for value in (
                self.legacy.profile["compiler_wrapper"], "/SYNTHETIC/alpha-backend", "/SYNTHETIC/python", "/SYNTHETIC/cc", "/SYNTHETIC/ld", "/SYNTHETIC/libgmp.so")]}
        (self.root / "PROFILE.json").write_text(json.dumps(self.profile, sort_keys=True))
        (self.root / "PREPARATION.json").write_bytes((V100 / "prepared/PREPARATION.json").read_bytes())
        self.roots = {key: "/SYNTHETIC-HOST/" + key for key in (
            "docker_config", "grant", "provider", "proposal", "fixtures", "profile", "evidence")}
        self.admission = {"format": "atlas-first-grant-build-terminal-admission-v1", "case": CASE,
            "cell": CELL, "required_matrix_size": 144, "token": "999999-1", "container_id": "c" * 64,
            "container_name": "atlas-grant-300-sqlite-debug-999999-1", "source_pins_sha256": self.pins,
            "profile_sha256": digest(self.root / "PROFILE.json"),
            "preparation_sha256": digest(self.root / "PREPARATION.json"), "roots": self.roots}
        self.report = self.legacy.report
        self.report.update(profile_sha256=self.admission["profile_sha256"],
            preparation_sha256=self.admission["preparation_sha256"],
            before=copy.deepcopy(self.report["build_window"]["before"]))
        for row in self.report["commands"]:
            row["elapsed_seconds"] = 1.0
        self.report["commands"][0]["wait4_maximum_rss_bytes"] = 1843200000
        limits = self.budget.Limits(2000000000, 4096)
        entry = {"identity": {"pid": 1, "ppid": 0, "pgid": 1, "sid": 1, "start_ticks": 12345},
            "cgroup_key": {"device": 30, "inode": 42}, "membership": "0::/\n", "members": [1],
            "self_peak_rss_kib": 12000, "waited_children_peak_rss_kib": 0,
            "snapshot": copy.deepcopy(self.report["before"]), "monotonic_ns": 1000}
        last = copy.deepcopy(entry)
        last.update(monotonic_ns=2000, waited_children_peak_rss_kib=1900000)
        self.lifetime = {"format": "atlas-first-grant-build-supervisor-lifetime-v1", "case": CASE, "cell": CELL,
            "required_matrix_size": 144, "source_pins_sha256": self.pins, "provider_pins_sha256": PROVIDER_PINS,
            "profile_sha256": self.admission["profile_sha256"], "preparation_sha256": self.admission["preparation_sha256"],
            "delegate_exit_code": 0, "wrapper_exit_code": 0, "errors": [], "single_supervisor_lifetime_verified": True,
            "actual_target_cells_accepted": 0, "cgroup_write_refusal_errno": 13, "entry": entry, "exit": last}
        self.plan = compose(HERE, dict(self.roots, profile_sha256=self.admission["profile_sha256"],
            preparation_sha256=self.admission["preparation_sha256"]), self.profile, "999999-1", self.pins)
        image = {"Id": "sha256:" + "b" * 64, "RepoDigests": ["python@" + self.plan["image"].split("@")[1]],
            "Config": {"Env": ["PATH=/usr/local/bin:/usr/bin:/bin"], "Labels": {}}}
        command = self.plan["create"][self.plan["create"].index(self.plan["image"]) + 1:]
        labels = {"org.amberframework.atlas.run": "999999-1",
            "org.amberframework.atlas.cell": "linux-amd64-sqlite-300-associations-debug-1",
            "org.amberframework.atlas.case": CASE}
        mounted = [("/usr", "/usr", False), ("/home/linuxbrew/.linuxbrew", "/home/linuxbrew/.linuxbrew", False),
            ("/etc/ld.so.cache", "/etc/ld.so.cache", False), ("/etc/ld.so.conf", "/etc/ld.so.conf", False),
            ("/etc/ld.so.conf.d", "/etc/ld.so.conf.d", False)]
        mounted += [(self.roots[key], target, key == "evidence") for key, target in (
            ("grant", "/grant"), ("provider", "/provider"), ("proposal", "/proposal"),
            ("fixtures", "/fixtures"), ("profile", "/profile.json"), ("evidence", "/evidence"))]
        base = {"Id": self.admission["container_id"], "Name": "/" + self.admission["container_name"],
            "Image": image["Id"], "Created": "2026-10-20T18:00:00Z",
            "Config": {"Image": self.plan["image"], "User": "501:501", "Cmd": command,
                "Entrypoint": None, "Env": image["Config"]["Env"], "Labels": labels, "WorkingDir": "/grant"},
            "HostConfig": {"NetworkMode": "none", "ReadonlyRootfs": True, "NanoCpus": 1000000000,
                "PidsLimit": 64, "Privileged": False, "CgroupnsMode": "private", "AutoRemove": False,
                "Memory": limits.hard_memory_bytes, "MemorySwap": limits.hard_memory_bytes, "CapDrop": ["ALL"],
                "CapAdd": None, "SecurityOpt": ["no-new-privileges"], "Tmpfs": {}, "PidMode": "", "Devices": [], "DeviceRequests": []},
            "Mounts": [{"Type": "bind", "Source": source, "Destination": target, "RW": rw,
                        "Propagation": "rprivate"} for source, target, rw in mounted]}
        self.inspections = {}
        for stage, status in (("created", "created"), ("running", "running"), ("terminal", "exited")):
            row = copy.deepcopy(base)
            row["State"] = {"Status": status, "Running": stage == "running", "Pid": 222 if stage == "running" else 0,
                "Paused": False, "Restarting": False, "Dead": False, "Error": "", "ExitCode": 0, "OOMKilled": False}
            self.inspections[stage] = row
        host = {"container_id": self.admission["container_id"],
            "identity": {"pid": 222, "ppid": 100, "pgid": 222, "sid": 222, "start_ticks": 12345},
            "cgroup_path": "/system.slice/docker-" + self.admission["container_id"] + ".scope",
            "cgroup_key": {"device": 30, "inode": 42}}
        host["membership"] = "0::" + host["cgroup_path"] + "\n"
        self.raw = {"precreate-absence-name": b"", "image-inspect": json.dumps([image]).encode(),
            "create": (self.admission["container_id"] + "\n").encode(), "start": (self.admission["container_id"] + "\n").encode(),
            "host-context": json.dumps(host).encode(), "wait": b"0\n", "logs": b"SOURCE-ONLY SYNTHETIC INPUT\n",
            "remove": (self.admission["container_id"] + "\n").encode(), "absence-id": b"", "absence-name": b""}
        self.journal_mutation = None

    def write_packet(self):
        for stage, value in self.inspections.items():
            self.raw[stage + "-inspect"] = json.dumps([value]).encode()
        steps = reader.expected_steps(self.plan, self.admission, 222, Path(self.roots["provider"]) / "tools/whole_build_memory")
        journal = []
        for ordinal, (label, argv) in enumerate(steps, 1):
            stdout, stderr = self.root / (label + ".stdout.txt"), self.root / (label + ".stderr.txt")
            stdout.write_bytes(self.raw[label])
            stderr.write_bytes(b"")
            journal.append({"ordinal": ordinal, "label": label, "arguments": argv, "exit_code": 0, "timed_out": False,
                "started_monotonic_ns": ordinal * 100, "ended_monotonic_ns": ordinal * 100 + 50,
                "stdout": reference(stdout), "stderr": reference(stderr)})
        if self.journal_mutation:
            self.journal_mutation(journal)
        (self.root / "HOST_COMMANDS.json").write_text(json.dumps(journal))
        (self.root / "SUPERVISOR_LIFETIME.json").write_text(json.dumps(self.lifetime))
        (self.root / "build/BUILD_OBSERVATION.json").write_text(json.dumps(self.report))

    def validate(self):
        self.write_packet()
        return reader.validate(self.root, self.admission, self.profile, self.preparation, self.pins,
            HERE, PROVIDER, self.budget, self.terminal, self.observation)

    def assert_refuses(self):
        with self.assertRaises((RuntimeError, ValueError, KeyError, TypeError)):
            self.validate()

    def test_complete_clearly_synthetic_packet_accepts_only_source_case(self):
        result = self.validate()
        self.assertTrue(result["successful_build_verified"])
        self.assertTrue(result["external_return_verified"])
        self.assertEqual(result["actual_target_cells_accepted"], 0)
        self.assertFalse(result["target_cell_accepted"])

    def test_changed_actual_ID_labels_image_and_command_refuse(self):
        original = copy.deepcopy(self.inspections)
        mutations = [(lambda value: value.update(Id="d" * 64)),
            (lambda value: value.update(Image="sha256:" + "d" * 64)),
            (lambda value: value["Config"]["Labels"].update({"org.amberframework.atlas.run": "another-run"})),
            (lambda value: value["Config"]["Cmd"].append("--no-codegen")),
            (lambda value: value["Config"].update(Entrypoint=["/bin/sh"])),
            (lambda value: value["Config"]["Env"].append("PYTHONPATH=/changed"))]
        for mutation in mutations:
            self.inspections = copy.deepcopy(original)
            mutation(self.inspections["terminal"])
            self.assert_refuses()

    def test_each_changed_mount_source_permission_extra_and_alias_refuses(self):
        original = copy.deepcopy(self.inspections)
        for index in range(11):
            with self.subTest(index=index):
                self.inspections = copy.deepcopy(original)
                self.inspections["terminal"]["Mounts"][index]["RW"] = not self.inspections["terminal"]["Mounts"][index]["RW"]
                self.assert_refuses()
        for mutation in ((lambda mounts: mounts[0].update(Source="/different-usr")),
                         (lambda mounts: mounts.append(copy.deepcopy(mounts[0]))),
                         (lambda mounts: mounts[0].update(Propagation="rshared")),
                         (lambda mounts: mounts[0].update(Type="volume"))):
            self.inspections = copy.deepcopy(original)
            mutation(self.inspections["terminal"]["Mounts"])
            self.assert_refuses()

    def test_changed_memory_swap_CPU_process_namespace_and_privilege_refuse(self):
        original = copy.deepcopy(self.inspections)
        for field, value in (("Memory", 2000000000), ("MemorySwap", 0), ("NanoCpus", 2000000000),
                ("PidsLimit", 128), ("CgroupnsMode", "host"), ("Privileged", True), ("AutoRemove", True),
                ("PidMode", "host"), ("CapAdd", ["SYS_ADMIN"]), ("Tmpfs", {"/extra": "rw"})):
            with self.subTest(field=field):
                self.inspections = copy.deepcopy(original)
                self.inspections["terminal"]["HostConfig"][field] = value
                self.assert_refuses()

    def test_nonterminal_OOM_and_nonzero_refuse_success(self):
        original = copy.deepcopy(self.inspections)
        for field, value in (("Status", "running"), ("Running", True), ("Pid", 222), ("Paused", True),
                             ("ExitCode", 2), ("OOMKilled", True), ("Error", "failure")):
            with self.subTest(field=field):
                self.inspections = copy.deepcopy(original)
                self.inspections["terminal"]["State"][field] = value
                self.assert_refuses()

    def test_actual_live_PID_cgroup_start_and_supervisor_identity_refuse(self):
        original = copy.deepcopy(self.lifetime)
        for mutation in ((lambda value: value["exit"]["identity"].update(start_ticks=54321)),
                         (lambda value: value["exit"].update(members=[1, 10])),
                         (lambda value: value["exit"]["cgroup_key"].update(inode=99)),
                         (lambda value: value["entry"]["identity"].update(pid=2)),
                         (lambda value: value["exit"].update(monotonic_ns=999)),
                         (lambda value: value.update(cgroup_write_refusal_errno=0))):
            self.lifetime = copy.deepcopy(original)
            mutation(self.lifetime)
            self.assert_refuses()

    def test_missing_wrong_and_still_present_final_absence_refuse(self):
        original = dict(self.raw)
        for label, value in (("absence-id", b"container-present\n"), ("absence-name", b"container-present\n"),
                             ("remove", b"different-id\n"), ("wait", b"1\n"), ("precreate-absence-name", b"already-present\n")):
            self.raw = dict(original, **{label: value})
            self.assert_refuses()

    def test_changed_external_commands_clock_exit_or_raw_binding_refuse(self):
        mutations = [(lambda rows: rows[-1]["arguments"].append("--changed")),
            (lambda rows: rows[-1].update(exit_code=1)), (lambda rows: rows[-1].update(timed_out=True)),
            (lambda rows: rows[-1].update(ended_monotonic_ns=1600 * 10**9)),
            (lambda rows: rows[-1]["stdout"].update(sha256="a" * 64)), (lambda rows: rows.pop()),
            (lambda rows: rows[0].update(ordinal=True)), (lambda rows: rows[-1].update(started_monotonic_ns=1))]
        for mutation in mutations:
            self.journal_mutation = mutation
            self.assert_refuses()

    def test_changed_profile_preparation_and_source_identity_refuse(self):
        original = copy.deepcopy(self.report)
        for field in ("profile_sha256", "preparation_sha256", "source_tree_sha256_after"):
            self.report = copy.deepcopy(original)
            self.report[field] = "f" * 64
            self.assert_refuses()

    def test_exact_compiler_and_whole_build_boundaries_refuse_reader(self):
        original = copy.deepcopy(self.report)
        for field in ("compiler", "final-cgroup", "decreasing-final"):
            self.report = copy.deepcopy(original)
            if field == "compiler":
                self.report["commands"][0]["wait4_maximum_rss_bytes"] = 2000000000
            elif field == "final-cgroup":
                self.report["final_raw_kernel_snapshot"]["memory_peak"] = 2000000000
            else:
                self.report["final_raw_kernel_snapshot"].update(memory_peak=1, memory_current=1)
            self.assert_refuses()

    def test_combined_raw_output_and_actual_measured_deadlines_refuse(self):
        original = copy.deepcopy(self.report)
        for mutation in ((lambda value: value["commands"][0].update(elapsed_seconds=901)),
                         (lambda value: value["commands"][1].update(elapsed_seconds=121)),
                         (lambda value: value["commands"][0]["stdout"].update(bytes=8 * 2**20)),
                         (lambda value: value["commands"][0]["stderr"].update(bytes=8 * 2**20 + 1))):
            self.report = copy.deepcopy(original)
            mutation(self.report)
            self.assert_refuses()
        self.report = copy.deepcopy(original)
        stdout, stderr = self.root / "build/build.stdout.txt", self.root / "build/build.stderr.txt"
        stdout.write_bytes(b"a" * (4 * 2**20))
        stderr.write_bytes(b"b" * (4 * 2**20 + 1))
        self.report["commands"][0].update(stdout=reference(stdout), stderr=reference(stderr))
        self.assertTrue(self.observation.validate(self.report, self.root / "build", self.profile,
            self.preparation, __import__("compile_acceptance_contract"), self.budget)["observation_replayed"])
        with self.assertRaisesRegex(RuntimeError, "combined stdout/stderr"):
            self.validate()

    def invoke_mocked_wrapper(self, report):
        captured = {}
        provider = mock.Mock()
        provider.limits = self.budget.Limits(2000000000, 4096)
        probe = mock.Mock()
        probe.cgroup_write_refusal.return_value = 13
        probe.alone.side_effect = [self.lifetime["entry"], self.lifetime["exit"]]
        worker = mock.Mock()
        worker.main.return_value = 0
        argv = ["run_first_grant_build.py", "--source-pins-sha256", self.pins,
            "--profile", "/profile.json", "--profile-sha256", self.admission["profile_sha256"],
            "--provider-root", "/provider", "--grant-root", "/grant", "--preparation", "/fixtures/PREPARATION.json",
            "--preparation-sha256", self.admission["preparation_sha256"], "--output", "/evidence/build"]
        def fake_digest(path):
            return self.admission["profile_sha256"] if str(path) == "/profile.json" else self.admission["preparation_sha256"]
        with mock.patch.object(sys, "argv", argv), mock.patch.object(sys, "platform", "linux"), \
             mock.patch("os.getpid", return_value=1), mock.patch("os.getuid", return_value=501), \
             mock.patch.object(Path, "exists", return_value=False), mock.patch.object(wrapper, "admit",
                return_value=(self.budget, self.terminal, probe, worker, self.observation)), \
             mock.patch.object(self.budget, "CurrentCgroup", return_value=provider), \
             mock.patch.object(wrapper, "digest", side_effect=fake_digest), \
             mock.patch.object(wrapper, "physical", return_value=json.dumps(report).encode()), \
             mock.patch.object(wrapper, "save", side_effect=lambda path, value: captured.update(copy.deepcopy(value))):
            code = wrapper.main()
        self.assertEqual(worker.main.call_count, 1)
        self.assertEqual(captured["entry"]["identity"], captured["exit"]["identity"])
        return code, captured

    def test_wrapper_same_process_delegation_and_boundary_nonzero(self):
        code, captured = self.invoke_mocked_wrapper(self.report)
        self.assertEqual(code, 0)
        self.assertEqual(captured["wrapper_exit_code"], 0)
        self.assertEqual(captured["delegate_exit_code"], 0)
        for mutation in ((lambda value: value["commands"][0].update(wait4_maximum_rss_bytes=2000000000)),
                         (lambda value: value["final_raw_kernel_snapshot"].update(memory_peak=2000000000)),
                         (lambda value: value["commands"][0].update(elapsed_seconds=901)),
                         (lambda value: value["final_raw_kernel_snapshot"].update(memory_peak=1, memory_current=1))):
            report = copy.deepcopy(self.report)
            mutation(report)
            code, captured = self.invoke_mocked_wrapper(report)
            self.assertEqual(code, 2)
            self.assertEqual(captured["wrapper_exit_code"], 2)
            self.assertEqual(captured["delegate_exit_code"], 0)
            self.assertTrue(captured["errors"])

    def test_failed_build_can_preserve_verified_external_return(self):
        self.inspections["terminal"]["State"]["ExitCode"] = 2
        self.raw["wait"] = b"2\n"
        self.write_packet()
        result = reader.validate_return(self.root, self.admission, self.profile, self.preparation, self.pins,
            HERE, PROVIDER, self.budget, self.terminal)
        self.assertTrue(result["external_return_verified"])
        self.assertEqual(result["terminal_exit_code"], 2)
        self.assertFalse(result["target_cell_accepted"])
        self.assert_refuses()

    def invoke_reader_cli(self, label):
        self.write_packet()
        admission = self.root / (label + "-ADMISSION.json")
        admission.write_text(json.dumps(self.admission))
        output = self.root / (label + "-READER_RESULT.json")
        argv = ["verify_first_grant_build.py", "--source-pins-sha256", self.pins,
            "--provider-root", str(PROVIDER), "--grant-root", str(WORK / "grant"),
            "--admission", str(admission), "--admission-sha256", digest(admission),
            "--evidence", str(self.root), "--output", str(output)]
        with mock.patch.object(sys, "argv", argv):
            code = reader.main()
        return code, json.loads(output.read_text())

    def test_actual_reader_entrypoint_returns_nonzero_at_both_strict_boundaries(self):
        code, result = self.invoke_reader_cli("normal-SYNTHETIC")
        self.assertEqual(code, 0)
        self.assertTrue(result["external_return_verified"])
        self.assertFalse(result["target_cell_accepted"])
        original = copy.deepcopy(self.report)
        for label in ("compiler", "whole-build"):
            self.report = copy.deepcopy(original)
            if label == "compiler":
                self.report["commands"][0]["wait4_maximum_rss_bytes"] = 2000000000
            else:
                self.report["final_raw_kernel_snapshot"]["memory_peak"] = 2000000000
            worker_code, worker_result = self.invoke_mocked_wrapper(self.report)
            reader_code, reader_result = self.invoke_reader_cli(label + "-boundary-SYNTHETIC")
            self.assertEqual(worker_code, 2)
            self.assertEqual(reader_code, 2)
            self.assertEqual(worker_result["wrapper_exit_code"], 2)
            self.assertTrue(reader_result["external_return_verified"])
            self.assertFalse(reader_result["successful_build_verified"])
            self.assertEqual(reader_result["actual_target_cells_accepted"], 0)

    def test_profile_that_the_original_reader_accepts_now_refuses(self):
        self.write_packet()
        invalid = {"compiler_wrapper": self.profile["compiler_wrapper"]}
        self.assertTrue(self.observation.validate(self.report, self.root / "build", invalid,
            self.preparation, __import__("compile_acceptance_contract"), self.budget)["observation_replayed"])
        self.profile = invalid
        (self.root / "PROFILE.json").write_text(json.dumps(invalid))
        self.admission["profile_sha256"] = digest(self.root / "PROFILE.json")
        self.report["profile_sha256"] = self.admission["profile_sha256"]
        self.assert_refuses()

    def test_independent_boolean_and_float_metadata_substitutions_refuse(self):
        original_inspections = copy.deepcopy(self.inspections)
        original_lifetime = copy.deepcopy(self.lifetime)
        original_admission = copy.deepcopy(self.admission)
        cases = []
        for stage in ("created", "running", "terminal"):
            if stage != "running":
                cases += [("pid-" + stage, lambda s=stage: self.inspections[s]["State"].update(Pid=False)),
                          ("float-pid-" + stage, lambda s=stage: self.inspections[s]["State"].update(Pid=0.0))]
            for field in ("Memory", "MemorySwap", "NanoCpus", "PidsLimit"):
                cases.append((stage + "-" + field, lambda s=stage, f=field:
                    self.inspections[s]["HostConfig"].update({f: float(original_inspections[s]["HostConfig"][f])})))
        cases += [("members-bool", lambda: self.lifetime["exit"].update(members=[True])),
            ("members-float", lambda: self.lifetime["exit"].update(members=[1.0])),
            ("delegate-exit-bool", lambda: self.lifetime.update(delegate_exit_code=False)),
            ("wrapper-exit-float", lambda: self.lifetime.update(wrapper_exit_code=0.0)),
            ("lifetime-count-float", lambda: self.lifetime.update(required_matrix_size=144.0)),
            ("admission-count-float", lambda: self.admission.update(required_matrix_size=144.0)),
            ("accepted-count-bool", lambda: self.lifetime.update(actual_target_cells_accepted=False))]
        for label, mutation in cases:
            with self.subTest(label=label):
                self.inspections = copy.deepcopy(original_inspections)
                self.lifetime = copy.deepcopy(original_lifetime)
                self.admission = copy.deepcopy(original_admission)
                mutation()
                self.assert_refuses()


if __name__ == "__main__":
    unittest.main()
