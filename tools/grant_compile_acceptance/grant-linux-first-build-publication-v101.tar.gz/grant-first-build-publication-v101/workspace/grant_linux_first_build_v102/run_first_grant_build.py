#!/usr/bin/env python3
"""Bind one PID-1 lifetime around the exact in-process predecessor worker."""
import argparse
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from source_admission import CASE, CELL, PROVIDER_PINS, STRICT_BYTES, admit, digest, need, parse, physical, save, verify_inner_bounds


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-pins-sha256", required=True)
    parser.add_argument("--profile", type=Path, required=True)
    parser.add_argument("--profile-sha256", required=True)
    parser.add_argument("--provider-root", type=Path, required=True)
    parser.add_argument("--grant-root", type=Path, required=True)
    parser.add_argument("--preparation", type=Path, required=True)
    parser.add_argument("--preparation-sha256", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = {"format": "atlas-first-grant-build-supervisor-lifetime-v1", "case": CASE, "cell": CELL,
        "source_pins_sha256": args.source_pins_sha256, "provider_pins_sha256": PROVIDER_PINS,
        "profile_sha256": args.profile_sha256, "preparation_sha256": args.preparation_sha256,
        "required_matrix_size": 144, "delegate_exit_code": None, "errors": [],
        "single_supervisor_lifetime_verified": False, "actual_target_cells_accepted": 0}
    original_argv = sys.argv[:]
    code = 2
    budget = provider = probe = None
    try:
        budget, _terminal, probe, worker, _observation = admit(Path(__file__).resolve().parent,
            args.source_pins_sha256, args.provider_root)
        import os
        need(sys.platform == "linux" and os.getpid() == 1 and os.getuid() == 501,
             "The exact non-root Linux PID-1 supervisor is required")
        need(args.output == Path("/evidence/build") and not args.output.exists(), "Fresh exact first-build evidence output required")
        need(digest(args.profile) == args.profile_sha256 and digest(args.preparation) == args.preparation_sha256,
             "Reviewed immutable native profile and complete300-model preparation required")
        provider = budget.CurrentCgroup(budget.Limits(STRICT_BYTES, os.sysconf("SC_PAGE_SIZE")))
        report["cgroup_write_refusal_errno"] = probe.cgroup_write_refusal()
        report["entry"] = probe.alone(budget, provider)
        # The original entry point executes in this supervisor, preserving PID1.
        sys.argv = [str(Path(__file__).resolve().parent / "vendor_v100/build_in_cgroup.py"),
            "--profile", str(args.profile), "--profile-sha256", args.profile_sha256,
            "--provider-root", str(args.provider_root), "--grant-root", str(args.grant_root),
            "--preparation", str(args.preparation), "--preparation-sha256", args.preparation_sha256,
            "--output", str(args.output), "--workload", "all_model_queries_and_associations"]
        code = worker.main()
        report["delegate_exit_code"] = code
        need(type(code) is int and code in (0, 2), "The original worker returns its exact integer exit protocol")
        if code == 0:
            verify_inner_bounds(parse(physical(args.output / "BUILD_OBSERVATION.json", 4 * 2**20)),
                                args.profile_sha256, args.preparation_sha256, budget)
    except BaseException as error:
        report["errors"].append(type(error).__name__ + ": " + str(error))
        code = 2
    finally:
        sys.argv = original_argv
        if probe is not None and provider is not None:
            try:
                report["exit"] = probe.alone(budget, provider)
                entry, last = report.get("entry"), report["exit"]
                need(entry is not None and entry["identity"] == last["identity"]
                     and entry["identity"]["pid"] == 1 and entry["members"] == last["members"] == [1]
                     and entry["cgroup_key"] == last["cgroup_key"], "The same PID-1 owner and cgroup must retire all descendants")
                report["single_supervisor_lifetime_verified"] = True
            except BaseException as error:
                report["errors"].append("final context: " + type(error).__name__ + ": " + str(error))
                # Preserve raw failure counters even when strict snapshot admission fails.
                try:
                    report["exit_raw_context"] = {"identity": probe.process_identity(budget),
                        "members": budget.read_small("/sys/fs/cgroup/cgroup.procs", 16384),
                        "snapshot": budget.asdict(budget.read_snapshot(lambda name:
                            budget.read_small(Path("/sys/fs/cgroup") / name)))}
                except BaseException as raw_error:
                    report["errors"].append("raw final context: " + str(raw_error))
                code = 2
        if report["errors"]:
            code = 2
        report["wrapper_exit_code"] = code
        save(args.output.parent / "SUPERVISOR_LIFETIME.json", report)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
