#!/usr/bin/env python3
"""Separately named external first-Grant-build case; original cases stay intact."""
import argparse
import errno
import hashlib
from pathlib import Path
import re
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from source_admission import CASE, CELL, PROVIDER_PINS, STRICT_BYTES, admit, digest, need, physical, read_json, save, verify_inner_bounds
from compose_first_build import compose


def artifact(root, row, maximum=2**20):
    need(type(row) is dict and set(row) == {"path", "bytes", "sha256"}, "Complete raw artifact reference required")
    need(type(row["path"]) is str and Path(row["path"]).name == row["path"]
         and row["path"] not in (".", "..") and type(row["bytes"]) is int and 0 <= row["bytes"] <= maximum
         and re.fullmatch("[0-9a-f]{64}", row["sha256"] or "") is not None, "Bounded portable raw artifact identity required")
    path = root / row["path"]
    raw = physical(path, maximum)
    need(len(raw) == row["bytes"] and hashlib.sha256(raw).hexdigest() == row["sha256"], "Raw artifact hash/length differs")
    return raw


def identity(value):
    need(type(value) is dict and set(value) == {"pid", "ppid", "pgid", "sid", "start_ticks"}
         and all(type(item) is int and item >= 0 for item in value.values())
         and value["pid"] > 0 and value["start_ticks"] > 0, "Complete typed actual process identity required")


def context(value, budget):
    identity(value["identity"])
    need(value["identity"]["pid"] == 1 and type(value["members"]) is list
         and all(type(member) is int for member in value["members"]) and value["members"] == [1]
         and value["membership"] == "0::/\n", "The single private PID-1 supervisor must retire every descendant")
    key = value["cgroup_key"]
    need(type(key) is dict and set(key) == {"device", "inode"}
         and all(type(item) is int and item > 0 for item in key.values()), "Actual complete physical cgroup identity required")
    need(type(value["monotonic_ns"]) is int and value["monotonic_ns"] > 0
         and type(value["self_peak_rss_kib"]) is int and value["self_peak_rss_kib"] > 0
         and type(value["waited_children_peak_rss_kib"]) is int and value["waited_children_peak_rss_kib"] >= 0,
         "Typed monotonic clock and actual RSS lifetime counters required")
    snapshot = budget.Snapshot(**value["snapshot"])
    budget.verify_snapshot(snapshot, budget.Limits(STRICT_BYTES, 4096))
    need(snapshot.pids_current == 1, "The complete descendant window ends with exactly its supervisor")


def admission_check(value, source_pins):
    need(type(value) is dict and value.get("format") == "atlas-first-grant-build-terminal-admission-v1"
         and value.get("case") == CASE and value.get("cell") == CELL
         and type(value.get("required_matrix_size")) is int and value["required_matrix_size"] == 144,
         "The separately named full300-model association cell and complete144-cell goal are required")
    for key in ("container_id", "profile_sha256", "preparation_sha256", "source_pins_sha256"):
        need(type(value.get(key)) is str and re.fullmatch("[0-9a-f]{64}", value[key]) is not None,
             "Complete exact admission identity required: " + key)
    need(value["source_pins_sha256"] == source_pins, "The external case source identity must match")
    need(re.fullmatch("[0-9]+-[0-9]+", value.get("token", "")) is not None
         and value["container_name"] == "atlas-grant-300-sqlite-debug-" + value["token"],
         "Exact run/attempt and fresh owned container name required")
    roots = value["roots"]
    need(type(roots) is dict and set(roots) == {"docker_config", "grant", "provider", "proposal", "fixtures", "profile", "evidence"},
         "The complete unique physical host mount/config roster is required")
    for path in roots.values():
        need(type(path) is str and Path(path).is_absolute() and Path(path).as_posix() == path
             and ".." not in Path(path).parts and all(char not in path for char in (",", "\0", "\n", "\r")),
             "Literal canonical absolute physical host roots required")


def expected_steps(plan, admission, running_pid, probe_root):
    docker = plan["create"][:plan["create"].index("create")]
    cid, name = admission["container_id"], admission["container_name"]
    return [("precreate-absence-name", docker + ["ps", "--all", "--no-trunc", "--filter", "name=^/" + name + "$", "--format", "{{.ID}}"]),
        ("image-inspect", docker + ["image", "inspect", plan["image"]]),
        ("create", plan["create"]), ("created-inspect", docker + ["inspect", cid]),
        ("start", docker + ["start", cid]), ("running-inspect", docker + ["inspect", cid]),
        ("host-context", ["/usr/bin/sudo", "--non-interactive", "/usr/bin/python3", "-I", "-S", "-B",
            str(probe_root / "probe.py"), "--pins-sha256", "233f9658ccd015e2c9e7c268723963ed3713dbb2fc4a552f65d2b52a13288cfd",
            "--host-pid", str(running_pid), "--container-id", cid]),
        ("wait", docker + ["wait", cid]), ("terminal-inspect", docker + ["inspect", cid]),
        ("logs", docker + ["logs", cid]), ("remove", docker + ["rm", "--force", cid]),
        ("absence-id", docker + ["ps", "--all", "--no-trunc", "--filter", "id=" + cid, "--format", "{{.ID}}"]),
        ("absence-name", docker + ["ps", "--all", "--no-trunc", "--filter", "name=^/" + name + "$", "--format", "{{.ID}}"])]


def validate_return(root, admission, profile, preparation, source_pins, here, provider_root, budget, terminal):
    admission_check(admission, source_pins)
    need(digest(root / "PROFILE.json") == admission["profile_sha256"]
         and digest(root / "PREPARATION.json") == admission["preparation_sha256"], "Actual reviewed profile/preparation artifacts differ")
    roots = dict(admission["roots"], profile_sha256=admission["profile_sha256"], preparation_sha256=admission["preparation_sha256"])
    plan = compose(here, roots, profile, admission["token"], source_pins)
    image_rows = read_json(root / "image-inspect.stdout.txt", terminal)
    need(type(image_rows) is list and len(image_rows) == 1, "One actual pinned Docker image required")
    image = image_rows[0]
    need(re.fullmatch("sha256:[0-9a-f]{64}", image.get("Id", "")) is not None
         and any(value in image["RepoDigests"] for value in (
             "python@" + plan["image"].split("@")[1], "docker.io/library/python@" + plan["image"].split("@")[1])),
         "Actual image identity must match the exact reviewed registry digest")
    inspections = {}
    created = None
    expected_mounts = {"/usr": ("/usr", False), "/home/linuxbrew/.linuxbrew": ("/home/linuxbrew/.linuxbrew", False),
        "/etc/ld.so.cache": ("/etc/ld.so.cache", False), "/etc/ld.so.conf": ("/etc/ld.so.conf", False),
        "/etc/ld.so.conf.d": ("/etc/ld.so.conf.d", False), "/grant": (roots["grant"], False),
        "/provider": (roots["provider"], False), "/proposal": (roots["proposal"], False),
        "/fixtures": (roots["fixtures"], False), "/profile.json": (roots["profile"], False), "/evidence": (roots["evidence"], True)}
    expected_labels = dict(image["Config"].get("Labels") or {}, **{
        "org.amberframework.atlas.run": admission["token"],
        "org.amberframework.atlas.cell": "linux-amd64-sqlite-300-associations-debug-1",
        "org.amberframework.atlas.case": CASE})
    command = plan["create"][plan["create"].index(plan["image"]) + 1:]
    for stage in ("created", "running", "terminal"):
        rows = read_json(root / (stage + "-inspect.stdout.txt"), terminal)
        need(type(rows) is list and len(rows) == 1, "Exactly one owned actual container per stage required")
        value = rows[0]
        need(value["Id"] == admission["container_id"] and value["Name"] == "/" + admission["container_name"]
             and value["Image"] == image["Id"], "Actual container ID/name/image binding changed")
        need(type(value["Created"]) is str and value["Created"].endswith("Z"), "Actual container creation timestamp required")
        created = value["Created"] if created is None else created
        need(value["Created"] == created, "All actual observations must retain one creation identity")
        config, host, state = value["Config"], value["HostConfig"], value["State"]
        need(config["Image"] == plan["image"] and config["Cmd"] == command and config["Entrypoint"] is None
             and config["Env"] == image["Config"]["Env"] and config["Labels"] == expected_labels
             and config["User"] == "501:501" and config["WorkingDir"] == "/grant",
             "Exact wrapper command, source/profile pins, image environment, labels and non-root workspace required")
        need(all(type(host[field]) is int for field in ("NanoCpus", "PidsLimit", "Memory", "MemorySwap"))
             and host["NetworkMode"] == "none" and host["ReadonlyRootfs"] is True and host["NanoCpus"] == 1000000000
             and host["PidsLimit"] == 64 and host["Privileged"] is False and host["CgroupnsMode"] == "private"
             and host["AutoRemove"] is False and host["Memory"] == host["MemorySwap"] == budget.Limits(STRICT_BYTES, 4096).hard_memory_bytes
             and host["CapDrop"] == ["ALL"] and host.get("CapAdd") in (None, [])
             and host["SecurityOpt"] in (["no-new-privileges"], ["no-new-privileges=true"])
             and host.get("Tmpfs") in (None, {}) and host.get("PidMode", "") == ""
             and host.get("Devices") in (None, []) and host.get("DeviceRequests") in (None, []),
             "Exact strict page-rounded no-swap finite isolated container profile required")
        mounts = value["Mounts"]
        need(type(mounts) is list and len(mounts) == len(expected_mounts)
             and len({row["Destination"] for row in mounts}) == len(mounts), "Complete unique read-only mount roster required")
        actual_mounts = {}
        for row in mounts:
            need(row["Type"] == "bind" and type(row["RW"]) is bool
                 and row.get("Propagation") == "rprivate", "Exact private bind mount semantics required")
            actual_mounts[row["Destination"]] = (row["Source"], row["RW"])
        need(actual_mounts == expected_mounts, "Actual host source/destination/read-only mount roster differs")
        need(state["Paused"] is False and state["Restarting"] is False and state["Dead"] is False
             and state["Error"] == "" and type(state["ExitCode"]) is int and type(state["OOMKilled"]) is bool,
             "Unambiguous typed actual container state required")
        if stage == "running":
            need(state["Status"] == "running" and state["Running"] is True and type(state["Pid"]) is int and state["Pid"] > 0,
                 "The actual container supervisor must be observed live")
        else:
            need(state["Status"] == ("created" if stage == "created" else "exited")
                 and state["Running"] is False and type(state["Pid"]) is int and state["Pid"] == 0,
                 "Exact created/terminal state and retired host PID required")
        if stage != "terminal":
            need(state["ExitCode"] == 0 and state["OOMKilled"] is False,
                 "The created and live first-build owner must retain a normal actual state")
        inspections[stage] = value
    steps = expected_steps(plan, admission, inspections["running"]["State"]["Pid"], Path(roots["provider"]) / "tools/whole_build_memory")
    journal = read_json(root / "HOST_COMMANDS.json", terminal, 4 * 2**20)
    need(type(journal) is list and len(journal) == len(steps), "Complete exact actual external command journal required")
    previous_end = 0
    raw = {}
    for ordinal, ((label, argv), row) in enumerate(zip(steps, journal), 1):
        need(row["label"] == label and type(row["ordinal"]) is int and row["ordinal"] == ordinal and row["arguments"] == argv
             and type(row["exit_code"]) is int and row["exit_code"] == 0
             and row["timed_out"] is False and type(row["started_monotonic_ns"]) is int
             and type(row["ended_monotonic_ns"]) is int
             and 0 <= previous_end < row["started_monotonic_ns"] <= row["ended_monotonic_ns"],
             "Exact successful serial external command/clock evidence required")
        previous_end = row["ended_monotonic_ns"]
        need(row["stdout"]["path"] == label + ".stdout.txt" and row["stderr"]["path"] == label + ".stderr.txt",
             "Each command must bind its complete named raw streams")
        raw[label] = artifact(root, row["stdout"], 8 * 2**20)
        need(artifact(root, row["stderr"], 8 * 2**20) == b"", "Successful external capture stderr must be empty")
    need(journal[-1]["ended_monotonic_ns"] - journal[0]["started_monotonic_ns"] <= 1500 * 10**9,
         "The complete original1500-second host interval includes final removal and absence")
    cid = admission["container_id"].encode()
    need(raw["create"] == raw["start"] == raw["remove"] == cid + b"\n", "Create/start/removal must read back the same actual complete Docker ID")
    need(raw["precreate-absence-name"] == raw["absence-id"] == raw["absence-name"] == b"",
         "The original fresh name and both final actual ID/name lookups must read back absent")
    terminal_exit = inspections["terminal"]["State"]["ExitCode"]
    need(0 <= terminal_exit <= 255 and raw["wait"] == (str(terminal_exit) + "\n").encode(), "Actual wait and terminal exit must agree")
    host = read_json(root / "host-context.stdout.txt", terminal)
    identity(host["identity"])
    need(type(host["cgroup_key"]) is dict and set(host["cgroup_key"]) == {"device", "inode"}
         and all(type(item) is int and item > 0 for item in host["cgroup_key"].values()),
         "Complete actual live host cgroup device/inode identity required")
    need(host["container_id"] == admission["container_id"] and host["identity"]["pid"] == inspections["running"]["State"]["Pid"]
         and host["membership"] == "0::" + host["cgroup_path"] + "\n"
         and Path(host["cgroup_path"]).name == "docker-" + admission["container_id"] + ".scope",
         "Actual live host PID and cgroup path must bind the exact Docker identity")
    return {"external_return_verified": True, "case": CASE, "cell": CELL, "required_matrix_size": 144,
        "container_id": admission["container_id"], "terminal_exit_code": terminal_exit,
        "terminal_OOMKilled": inspections["terminal"]["State"]["OOMKilled"], "actual_target_cells_accepted": 0,
        "target_cell_accepted": False, "host_context": host, "plan": plan}


def validate(root, admission, profile, preparation, source_pins, here, provider_root, budget, terminal, observation):
    returned = validate_return(root, admission, profile, preparation, source_pins, here, provider_root, budget, terminal)
    need(returned["terminal_exit_code"] == 0 and returned["terminal_OOMKilled"] is False,
         "A successful first build requires its actual zero terminal exit and absent OOM marker")
    lifetime = read_json(root / "SUPERVISOR_LIFETIME.json", terminal)
    need(lifetime["format"] == "atlas-first-grant-build-supervisor-lifetime-v1" and lifetime["case"] == CASE
         and lifetime["cell"] == CELL and type(lifetime["required_matrix_size"]) is int and lifetime["required_matrix_size"] == 144
         and lifetime["source_pins_sha256"] == source_pins and lifetime["provider_pins_sha256"] == PROVIDER_PINS
         and lifetime["profile_sha256"] == admission["profile_sha256"]
         and lifetime["preparation_sha256"] == admission["preparation_sha256"]
         and type(lifetime["delegate_exit_code"]) is int and type(lifetime["wrapper_exit_code"]) is int
         and lifetime["delegate_exit_code"] == lifetime["wrapper_exit_code"] == 0 and lifetime["errors"] == []
         and lifetime["single_supervisor_lifetime_verified"] is True
         and type(lifetime["actual_target_cells_accepted"]) is int and lifetime["actual_target_cells_accepted"] == 0
         and type(lifetime["cgroup_write_refusal_errno"]) is int
         and lifetime["cgroup_write_refusal_errno"] in (errno.EROFS, errno.EPERM, errno.EACCES),
         "The original in-process worker must complete inside the single source-bound lifetime")
    entry, last = lifetime["entry"], lifetime["exit"]
    context(entry, budget)
    context(last, budget)
    host = returned["host_context"]
    need(entry["identity"] == last["identity"] and entry["cgroup_key"] == last["cgroup_key"] == host["cgroup_key"]
         and entry["identity"]["start_ticks"] == host["identity"]["start_ticks"]
         and last["monotonic_ns"] > entry["monotonic_ns"]
         and last["self_peak_rss_kib"] >= entry["self_peak_rss_kib"]
         and last["waited_children_peak_rss_kib"] >= entry["waited_children_peak_rss_kib"],
         "Entry/exit and actual external live PID must bind the same lifetime, physical cgroup and monotonic RSS")
    budget.compare_snapshots(budget.Snapshot(**entry["snapshot"]), budget.Snapshot(**last["snapshot"]), budget.Limits(STRICT_BYTES, 4096))
    report = read_json(root / "build/BUILD_OBSERVATION.json", terminal, 4 * 2**20)
    verify_inner_bounds(report, admission["profile_sha256"], admission["preparation_sha256"], budget)
    observation.validate(report, root / "build", profile, preparation,
        __import__("compile_acceptance_contract"), budget)
    need(entry["snapshot"]["memory_peak"] <= report["before"]["memory_peak"]
         <= report["build_window"]["after"]["memory_peak"] <= report["final_raw_kernel_snapshot"]["memory_peak"]
         <= last["snapshot"]["memory_peak"], "The same lifetime kernel peak must cover the complete actual build/runtime window")
    need(last["waited_children_peak_rss_kib"] * 1024 >= report["commands"][0]["wait4_maximum_rss_bytes"],
         "The supervisor's retired-child RSS must cover its actual compiler upper-bound observation")
    returned.update(successful_build_verified=True, single_supervisor_lifetime_verified=True,
        inner_observation_replayed=True, original_144_cell_acceptance="pending",
        actual_native_provider_integration_qualification="pending-real-hosted-execution")
    returned.pop("plan")
    return returned


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-pins-sha256", required=True)
    parser.add_argument("--provider-root", type=Path, required=True)
    parser.add_argument("--grant-root", type=Path, required=True)
    parser.add_argument("--admission", type=Path, required=True)
    parser.add_argument("--admission-sha256", required=True)
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = {"format": "atlas-first-grant-build-external-case-result-v1", "case": CASE,
        "successful_build_verified": False, "external_return_verified": False, "actual_target_cells_accepted": 0, "errors": []}
    try:
        here = Path(__file__).resolve().parent
        budget, terminal, _probe, _worker, observation = admit(here, args.source_pins_sha256, args.provider_root)
        need(digest(args.admission) == args.admission_sha256, "Independent parent actual-ID admission receipt must match")
        admission = read_json(args.admission, terminal)
        profile = read_json(args.evidence / "PROFILE.json", terminal)
        preparation = read_json(args.evidence / "PREPARATION.json", terminal, 4 * 2**20)
        contract_row = next(row for row in preparation["source_files"] if row["path"] == "scripts/compile_acceptance_contract.py")
        need(digest(args.grant_root / contract_row["path"]) == contract_row["sha256"], "Exact original Grant behavior reader required")
        sys.path.insert(0, str(args.grant_root / "scripts"))
        result.update(validate_return(args.evidence, admission, profile, preparation, args.source_pins_sha256,
            here, args.provider_root, budget, terminal))
        result.pop("plan", None)
        result.update(validate(args.evidence, admission, profile, preparation, args.source_pins_sha256,
            here, args.provider_root, budget, terminal, observation))
    except BaseException as error:
        result["errors"].append(type(error).__name__ + ": " + str(error))
    finally:
        save(args.output, result)
    return 0 if result["successful_build_verified"] and result["external_return_verified"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
