# First Grant build: complete external reader and one supervisor lifetime

Mission: `memory-budget-experiment`. This is the fresh `v102` implementation successor to preserved `grant_linux_first_build_v100` and reviewed `v101/2dad77ee`. It supplies the separately named first-build external case, **`first-grant-build-linux-sqlite-300-associations-debug-repetition-1`**, with exact-integer metadata guards. The selected workload remains the complete original **300-model SQLite association debug build**, with900 create/hydrate/scope operations,4,800 field checks, and900 direct/reverse/eager association checks. All144 final cells remain required; accepted target cells remain0/144.

## Implemented behavior

`run_first_grant_build.py` executes the exact reviewed v100 `build_in_cgroup.main()` **inside the same PID-1 process**. It captures the existing accepted provider's `probe.alone`/context before delegation and after the last worker retires. The stable start ticks, PID1, physical cgroup device/inode, private membership, descendant roster, lifetime RSS and kernel snapshots remain attached to that single supervisor. The wrapper preserves failure errors and raw final context when strict final observation fails.

The wrapper's own entry point returns2 when compiler RSS or any required build/final charged-memory snapshot reaches **2,000,000,000 bytes**, when a lifetime peak decreases, when profile/preparation identities differ, when combined stdout/stderr exceeds8MiB, or when measured command duration exceeds900 seconds for compilation or120 seconds for runtime. The original delegate's reported status remains recorded separately. A normal source fixture returns0. These entry-point outcomes are executed **source-only mocked controls**; actual compiler and kernel integration remain pending.

`verify_first_grant_build.py` imports the exact accepted `verify_terminal.read_json`, cgroup `Limits`/`Snapshot`/validation helpers, and the original Grant behavior reader. It adds this first-build case through a new file and leaves every original provider case intact. It validates:

- Actual created, running and terminal Docker observations for one complete ID, name, creation identity, registry image digest and exact run/cell/case labels.
- Exact wrapper argv, source/profile/preparation hashes, base-image environment, non-root user and `/grant` working directory.
- All11 private bind mounts, including every exact host source, destination and read-only flag; only owned evidence is writable.
- The strict **1,999,998,976-byte** page-rounded kernel ceiling, equal memory/swap limits, one CPU,64 process slots, private cgroup/PID scope and reduced privileges.
- The actual live host PID and Docker cgroup path joined to the same supervisor start ticks and cgroup device/inode in both lifetime endpoints.
- Four original complete compiler/runtime commands, executed model/field/association behavior, same-binary corruption failures, complete raw output and monotonic memory peaks.
- A13-command external journal with serial monotonic clocks, exact argv, complete stdout/stderr hashes, actual wait status, ID-bound removal, and final empty lookups by both actual ID and exact name.

The independent external return check remains available for failed builds. A failed compiler can have a verified container/resource return while the normal success reader and CLI return2. Raw compiler output, failure context, kernel observations and cleanup remain preserved as evidence. The CLI writes its result even on refusal.

## Source and provenance

The exact three v100 implementation files are copied byte-for-byte under `vendor_v100/`; the v100 directory and its original receipt `e201a2bf6c56f57498146dfcdfcb19e6fcda4f21110842f5ed3908d09f5fd66e` remain unchanged. Existing provider sources are imported from SDK commit `372bc3379c07c8e75ba92cb6d8a40e57ecbb8bfe`, with installation manifest `15e27eea749e5d08f7d41256515b078f256c89fed5c49647c09dc99b99406eae` and whole-build manifest `233f9658ccd015e2c9e7c268723963ed3713dbb2fc4a552f65d2b52a13288cfd`. `SOURCE_PINS.json` binds all executable/test successor files and the copies.

The original peer findings are retained at `../grant_linux_first_build_peer_v100/`. Its six-case reproduction digest is `9e411dac327bc8abe7a9149199421a64aa83f33b8f5d2959895efc914f11a641`; its complete review receipt is `5db60ddc57a74176b7f7f0667e72c9ed1705f9ca9e633b5a8da4ab18e64396b6`. The successor checks deliberately reproduce the invalid profile, combined8,388,609-byte output,901/121-second durations, exclusive-limit peak and decreasing terminal peak. The physical combined-output control is accepted by the old reader and refused by the successor. Both exclusive-boundary cases produce wrapper2 and reader2 while preserving verified external return.

The independent v101 review then demonstrated13 boolean/float substitutions accepted through numeric equality, including terminal PIDfalse, float container limits, memberstrue, and float matrix/status counts. Its exact reproduction SHA-256 is `4962747d0d4820f4152104d97db3b28273f00c64d22a92ad5cfc57d08dbf2644`. This fresh v102 applies exact integer guards to every matching created/running/terminal PID and limit, supervisor member, delegate/wrapper status and acceptance/matrix count. The original v101 manifest `2dad77ee9f0c2a9ad09d084c92656107e081df8bd8224cafbdf8d89bf8a76f4e`, source-test receipt `d36f26bca85b73b4e713e1e826faf6b9463b854245a76ad832f260af15caac4f`, and all22 frozen source/report paths remain byte-for-byte preserved. `ANCESTOR_SOURCE_ROSTER.json` binds those named originals, the21 v100 source rows and peer evidence; no original acceptance is relabeled.

The formula SHA-256 **`7ce1726c8c792836ec6e84013a1906c800dfaefc30954e96f0974a6bf17ab5f7` in the v100 README is the predecessor**. The current reviewed **revision1** formula is **`dfb16338b328960bd0e822c2d98eac8b7774d1303e972a5dba09ba1ddf9ab7df`**, verified against the saved actual formula. `FORMULA_SUCCESSOR_NOTE.json` records this transition without rewriting v100 history.

## Execution and artifacts

Source tests:

```sh
PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 -I -S -B -m unittest discover \
  -s .luna/atlas-work/grant_linux_first_build_v102 -p 'test_first_grant_external.py' -v
```

The exact host mount-root/profile preparation from v100 remains in use. `compose_first_build.py` reuses its original Docker composer, adds the new case label and source hash, and selects the new same-process wrapper:

```sh
python3 -I -S -B compose_first_build.py \
  --source-pins-sha256 <reviewed-successor-manifest-sha256> \
  --provider-root <exact-SDK-checkout> \
  --profile <reviewed-actual-Linux-profile.json> \
  --profile-sha256 <reviewed-actual-profile-sha256> \
  --preparation-sha256 7c24a1ca2f2832273daf5ecc8b73e955189acc13e4fa0b720fdcecf9d38ef9a0 \
  --roots <actual-physical-mount-roots.json> --token <run-id>-<attempt> \
  --output <fresh-dispatch-plan.json>
```

The host retains this exact ordered command roster: `precreate-absence-name`, `image-inspect`, `create`, `created-inspect`, `start`, `running-inspect`, `host-context`, `wait`, `terminal-inspect`, `logs`, `remove`, `absence-id`, `absence-name`. Each journal row records ordinal, actual argv, exit, timeout flag, monotonic entry/return clocks, and complete raw stdout/stderr file identities. The create result supplies the actual64-digit Docker ID; subsequent mutations/readbacks bind that ID. `host-context` executes the already accepted `probe.py --host-pid ... --container-id ...` metadata collector. Its exact expected argv is generated by `expected_steps`.

Retain `PROFILE.json`, `PREPARATION.json`, `HOST_COMMANDS.json`, all26 raw external streams, `SUPERVISOR_LIFETIME.json`, and the complete `build/` output including actual binary, fixture behavior, normal/corruption streams and `BUILD_OBSERVATION.json`. Parent admission binds the actual container ID, run/attempt, source/profile/preparation identities and physical mount roots. The source fixture class is explicitly named `SyntheticExternalControls`; its invented host paths and Docker IDs carry `SYNTHETIC` markers or fixture-only values.

After terminal capture, exact removal and absence readback, invoke the external reader:

```sh
python3 -I -S -B verify_first_grant_build.py \
  --source-pins-sha256 <reviewed-successor-manifest-sha256> \
  --provider-root <exact-SDK-checkout> --grant-root <exact-Grant-source> \
  --admission <parent-actual-ID-admission.json> \
  --admission-sha256 <independently-reviewed-admission-sha256> \
  --evidence <returned-evidence-root> --output <fresh-external-result.json>
```

Its successful result verifies this source-bound build/return case and continues to report target-cell acceptancefalse. Actual compiler-RSS/provider integration qualification, ordinary installation, native runtime projection, original144-cell acceptance and public release remain separate required evidence. Actual compilation/container/SSH jobs in this source implementation are0. The parent owns public integration and actual hosted dispatch after ordinary SDK readiness and native-profile admission.

Crystal conventions/rubric were loaded. New Crystal edits0; all Crystal MAJOR items are not applicable to this Python-only successor. Actual Crystal compile color remains **UNEXECUTED**.
