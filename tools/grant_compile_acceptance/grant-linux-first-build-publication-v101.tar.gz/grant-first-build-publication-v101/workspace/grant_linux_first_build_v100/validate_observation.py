#!/usr/bin/env python3
"""Replay the integration observation; final cell qualification stays separate."""
import hashlib
import argparse
import importlib
import json
from pathlib import Path
import re
import sys


def need(value, message):
    if not value:
        raise ValueError(message)


def validate(report, root, profile, preparation, contract, budget):
    need(type(report) is dict and report.get("format") == "atlas-grant-first-linux-build-observation-v1",
         "Exact observation format required")
    need(report.get("observation_passed") is True and report.get("errors") == [],
         "An actual successful observation is required")
    need(report.get("target_cell_accepted") is False and report.get("full_matrix_accepted") is False
         and type(report.get("actual_target_cells_accepted")) is int and report["actual_target_cells_accepted"] == 0,
         "Observation and final qualified target acceptance retain distinct states")
    need(report.get("compiler_color") == "GREEN", "Zero-error zero-warning compiler output required")
    need(report.get("source_tree_sha256_before") == report.get("source_tree_sha256_after")
         == preparation["source_tree_sha256"], "Complete source/dependency before/after identity required")
    commands = report.get("commands")
    workload = preparation["first_selected_cell"].split("/")[3]
    expected = ["build", "normal", "field-canary", "association-canary"]
    need(type(commands) is list and len(commands) == len(expected), "Complete unique actual command roster required")

    def verify_artifact(row, expected_name, maximum=8 * 2**20, text=True):
        need(type(row) is dict and set(row) == {"path", "bytes", "sha256"} and row["path"] == expected_name,
             "Exact relative raw artifact identity required")
        need(type(row["bytes"]) is int and 0 <= row["bytes"] <= maximum
             and re.fullmatch("[0-9a-f]{64}", row["sha256"] or "") is not None,
             "Typed bounded hash-bearing artifact required")
        path = root / expected_name
        need(path.is_file() and not path.is_symlink() and path.stat().st_size == row["bytes"]
             and hashlib.sha256(path.read_bytes()).hexdigest() == row["sha256"],
             "Actual raw artifact changed")
        return path.read_text() if text else None

    raw = {}
    for label, command in zip(expected, commands):
        need(type(command.get("direct_pid")) is int and command["direct_pid"] > 0
             and command.get("timed_out") is False and command.get("raw_output_budget_exceeded") is False,
             "Actual bounded child execution required")
        need(type(command.get("exit_code")) is int, "Typed actual child exit required")
        raw[label] = (verify_artifact(command["stdout"], label + ".stdout.txt"),
                      verify_artifact(command["stderr"], label + ".stderr.txt"))
    build = commands[0]
    need(build["arguments"][0] == profile["compiler_wrapper"]
         and build["arguments"][1:7] == ["build", "--no-color", "-Dwithout_mt", "--threads", "1", "/fixtures/sqlite-300-all_model_queries_and_associations.cr"]
         and build["arguments"][7:] == ["-o", "/evidence/build/fixture"],
         "Exact complete one-worker original-fixture compiler command required")
    need(build["exit_code"] == 0 and commands[1]["exit_code"] == 0,
         "Actual build and ordinary runtime behavior must pass")
    need(type(build.get("wait4_maximum_rss_bytes")) is int and 0 < build["wait4_maximum_rss_bytes"] < 2000000000,
         "Strict conservative compiler RSS bound exceeded")
    need(not re.search(r"\bwarning\b", "".join(raw["build"]), re.IGNORECASE), "Actual compiler warnings reject GREEN")
    markers = [line.split("=", 1)[1] for line in raw["normal"][0].splitlines()
               if line.startswith("GRANT_COMPILE_ACCEPTANCE_BEHAVIOR=")]
    need(len(markers) == 1, "One actual complete runtime behavior marker required")
    contract.verify_behavior(contract.parse_json_text(markers[0]), 300, workload)
    for index, (label, assertion) in enumerate((("field-canary", "AcceptancePerson0000 field first_name"),
                ("association-canary", "AcceptancePerson0000 parent model identity")), 2):
        need(commands[index]["exit_code"] != 0 and assertion in raw[label][1],
             "The exact same executable must reject each actual targeted corruption")
    for command in commands[1:]:
        need(command["arguments"] == ["/evidence/build/fixture"], "The same artifact must execute in every runtime control")
    binary = report.get("binary")
    need(type(binary) is dict and binary.get("path") == "fixture", "Actual resulting binary artifact required")
    verify_artifact(binary, "fixture", maximum=256 * 2**20, text=False)
    window = report.get("build_window")
    need(type(window) is dict and window.get("scope") == "current-cgroup-and-descendants-through-final-snapshot-v1",
         "The existing provider's complete build window is required")
    need(window["limits"]["strict_memory_bytes"] == 2000000000
         and window["limits"]["cpu_quota"] == window["limits"]["cpu_period"] == 100000
         and window["limits"]["maximum_processes"] == 64,
         "Exact strict kernel memory, CPU and process profile required")
    limits = budget.Limits(**window["limits"])
    budget.compare_snapshots(budget.Snapshot(**window["before"]), budget.Snapshot(**window["after"]), limits)
    for snapshot in (window["before"], window["after"], report["final_raw_kernel_snapshot"]):
        budget.verify_snapshot(budget.Snapshot(**snapshot), limits)
        need(type(snapshot["memory_peak"]) is int and 0 < snapshot["memory_peak"] < 2000000000
             and snapshot["memory_max"] == 1999998976 and snapshot["swap_max"] == snapshot["swap_current"] == 0
             and snapshot["pids_current"] == 1 and all(type(value) is int and value == 0
                                                       for value in snapshot["memory_events"].values()),
             "Actual strict kernel peak, unchanged ceiling and clean terminal counters required")
    need(window["after"]["memory_peak"] >= window["before"]["memory_peak"], "Lifetime cgroup peak must remain monotonic")
    need(report["final_members"] == "1\n", "All compiler, linker and runtime writers must retire")
    need(report.get("external_terminal_inspection_and_exact_container_removal") == "required-pending",
         "The separate external terminal inspection and exact removal remain required")
    return {"observation_replayed": True, "target_cell_accepted": False, "required_matrix_size": 144}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--profile", type=Path, required=True)
    parser.add_argument("--preparation", type=Path, required=True)
    parser.add_argument("--preparation-sha256", required=True)
    parser.add_argument("--grant-root", type=Path, required=True)
    parser.add_argument("--provider-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    need(hashlib.sha256(args.preparation.read_bytes()).hexdigest() == args.preparation_sha256,
         "Reviewed immutable preparation identity required")
    preparation = json.loads(args.preparation.read_text())
    row = next(item for item in preparation["source_files"] if item["path"] == "scripts/compile_acceptance_contract.py")
    need(hashlib.sha256((args.grant_root / row["path"]).read_bytes()).hexdigest() == row["sha256"],
         "Exact existing Grant behavior validator required")
    manifest = args.provider_root / "tools/installation_provenance/SOURCE_PINS.json"
    need(hashlib.sha256(manifest.read_bytes()).hexdigest() == preparation["provider_pins_sha256"],
         "Exact accepted provider manifest required")
    row = next(item for item in json.loads(manifest.read_text())["files"] if item["path"] == "cgroup_budget.py")
    need(hashlib.sha256((manifest.parent / row["path"]).read_bytes()).hexdigest() == row["sha256"],
         "Exact existing kernel validator required")
    sys.path.insert(0, str(args.grant_root / "scripts"))
    sys.path.insert(0, str(manifest.parent))
    contract = importlib.import_module("compile_acceptance_contract")
    budget = importlib.import_module("cgroup_budget")
    result = validate(contract.parse_json(args.evidence / "BUILD_OBSERVATION.json"), args.evidence,
        contract.parse_json(args.profile), preparation, contract, budget)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
