#!/usr/bin/env python3
"""Collect one actual Grant build inside the existing admitted Linux cgroup.

This integration candidate collects a real complete build, its binary behavior,
and a conservative compiler RSS bound. Actual provider integration qualification
and the 144-cell final acceptance remain explicit downstream requirements.
"""
import argparse
import errno
import hashlib
import importlib
import json
import os
from pathlib import Path
import re
import signal
import stat
import sys
import time

STRICT_BYTES = 2000000000


def need(value, message):
    if not value:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def artifact(path):
    return {"path": path.name, "bytes": path.stat().st_size, "sha256": digest(path)}


def verify_profile(value):
    need(type(value) is dict and value.get("format") == "atlas-grant-linux-build-integration-profile-v1",
         "Reviewed Linux build integration profile required")
    need(value.get("platform") == "linux-amd64" and value.get("ordinary_alpha_installation_ready") is True,
         "Actual ordinary Linux Alpha installation readiness is required")
    need(re.fullmatch("[0-9a-f]{64}", value.get("readiness_receipt_sha256", "")) is not None,
         "Exact actual successful installation receipt identity is required")
    need(value.get("runtime_projection_reviewed") is True,
         "The host-to-container native runtime projection requires independent review")
    need(type(value.get("files")) is list and len(value["files"]) >= 6,
         "Compiler, Python, C compiler, linker and native dependency identities are required")
    paths = [row.get("path") for row in value["files"]]
    need(len(paths) == len(set(paths)), "Unique native input identities are required")
    for row in value["files"]:
        need(set(row) == {"path", "sha256"} and type(row["path"]) is str
             and Path(row["path"]).is_absolute() and re.fullmatch("[0-9a-f]{64}", row["sha256"] or "") is not None,
             "Complete absolute hash-bound native input identities required")
    need(value.get("compiler_wrapper") in paths and value.get("compiler_backend") in paths,
         "Actual ordinary compiler wrapper/backend binding is required")
    environment = value.get("compiler_environment")
    need(type(environment) is dict and set(environment) <= {
        "PATH", "CRYSTAL_LIBRARY_PATH", "CRYSTAL_LIBRARY_RPATH", "LD_LIBRARY_PATH"},
        "The reviewed compiler environment has a finite declared variable roster")
    need(type(environment.get("PATH")) is str and all(type(item) is str and "\0" not in item for item in environment.values()),
         "Literal reviewed compiler environment required")
    return value


def verify_files(value):
    for row in value["files"]:
        need(Path(row["path"]).is_file() and digest(row["path"]) == row["sha256"],
             "Native compiler/runtime source changed: " + row["path"])


def read_behavior(path, contract, count, workload):
    rows = [line.split("=", 1)[1] for line in path.read_text().splitlines()
            if line.startswith("GRANT_COMPILE_ACCEPTANCE_BEHAVIOR=")]
    need(len(rows) == 1, "One actual executed complete behavior marker is required")
    value = contract.parse_json_text(rows[0])
    contract.verify_behavior(value, count, workload)
    return value


def run_command(arguments, environment, cwd, output, label, seconds):
    stdout_path, stderr_path = output / (label + ".stdout.txt"), output / (label + ".stderr.txt")
    started = time.monotonic()
    timed_out, output_exceeded = False, False
    with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
        pid = os.fork()
        if pid == 0:
            os.chdir(cwd)
            os.dup2(stdout.fileno(), 1)
            os.dup2(stderr.fileno(), 2)
            try:
                os.execve(arguments[0], arguments, environment)
            except OSError as error:
                os.write(2, (str(error) + "\n").encode())
                os._exit(127)
        while True:
            waited, status, usage = os.wait4(pid, os.WNOHANG)
            if waited:
                break
            timed_out = time.monotonic() - started > seconds
            output_exceeded = stdout_path.stat().st_size + stderr_path.stat().st_size > 8 * 2**20
            if timed_out or output_exceeded:
                # The still-unreaped direct child retains this PID identity.
                os.kill(pid, signal.SIGKILL)
                waited, status, usage = os.wait4(pid, 0)
                break
            time.sleep(.02)
    need(waited == pid, "The actual direct build/runtime child must be reaped")
    output_exceeded = output_exceeded or stdout_path.stat().st_size + stderr_path.stat().st_size > 8 * 2**20
    return {"arguments": arguments, "direct_pid": pid, "exit_code": os.waitstatus_to_exitcode(status),
            "timed_out": timed_out, "raw_output_budget_exceeded": output_exceeded,
            "elapsed_seconds": time.monotonic() - started,
            "wait4_maximum_rss_bytes": usage.ru_maxrss * 1024,
            "rss_semantics": "Linux wait4 largest direct-or-waited-descendant high-water RSS; conservative compiler upper bound; concurrent totals use the separate cgroup metric",
            "stdout": artifact(stdout_path), "stderr": artifact(stderr_path)}


def alone(budget, provider):
    # PID 1 owns adopted descendants. A surviving writer makes the window fail;
    # the external host then removes the exact whole container and verifies it.
    while True:
        try:
            child, _status = os.waitpid(-1, os.WNOHANG)
            if child == 0:
                break
        except ChildProcessError:
            break
    members = [int(row) for row in budget.read_small("/sys/fs/cgroup/cgroup.procs", 16384).splitlines()]
    need(members == [os.getpid()], "Every owned compiler/linker/runtime descendant must retire")
    snapshot = provider.snapshot()
    need(snapshot.pids_current == 1, "The complete cgroup window must end with its supervisor alone")
    return snapshot


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", type=Path, required=True)
    parser.add_argument("--profile-sha256", required=True)
    parser.add_argument("--provider-root", type=Path, required=True)
    parser.add_argument("--grant-root", type=Path, required=True)
    parser.add_argument("--preparation", type=Path, required=True)
    parser.add_argument("--preparation-sha256", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workload", choices=("all_model_queries", "all_model_queries_and_associations"),
                        default="all_model_queries_and_associations")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    report = {"format": "atlas-grant-first-linux-build-observation-v1", "observation_passed": False,
              "target_cell_accepted": False, "full_matrix_accepted": False, "actual_target_cells_accepted": 0,
              "whole_build_integration_qualification": "pending", "compiler_rss_integration_qualification": "pending",
              "compiler_color": "UNEXECUTED", "errors": [], "commands": []}
    budget, provider = None, None
    try:
        need(sys.platform == "linux" and os.getpid() == 1 and os.getuid() == 501,
             "The dedicated non-root PID-1 Linux namespace supervisor is required")
        need(digest(args.profile) == args.profile_sha256, "The independent reviewed native profile must match its supplied hash")
        profile = verify_profile(json.loads(args.profile.read_text()))
        verify_files(profile)
        need(digest(args.preparation) == args.preparation_sha256, "The reviewed complete preparation must retain its source identity")
        preparation = json.loads(args.preparation.read_text())
        report["preparation_sha256"] = args.preparation_sha256
        report["profile_sha256"] = args.profile_sha256
        report["source_tree_sha256_before"] = preparation["source_tree_sha256"]
        need(preparation["grant_source_commit"] == "d78418566d90e61d6876a4a2a8abd93bb74f1ba1"
             and preparation["required_matrix_size"] == 144, "The complete original source/contract remains required")
        manifest = args.provider_root / "tools/installation_provenance/SOURCE_PINS.json"
        need(digest(manifest) == preparation["provider_pins_sha256"], "Exact existing qualified kernel provider required")
        for row in json.loads(manifest.read_text())["files"]:
            path = manifest.parent / row["path"]
            need(not path.is_symlink() and path.stat().st_size == row["bytes"]
                 and stat.S_IMODE(path.stat().st_mode) == row["mode"] and digest(path) == row["sha256"],
                 "Existing qualified provider member changed")
        sys.path.insert(0, str(manifest.parent))
        budget = importlib.import_module("cgroup_budget")
        provider = budget.CurrentCgroup(budget.Limits(STRICT_BYTES, os.sysconf("SC_PAGE_SIZE")))
        sys.path.insert(0, str(args.grant_root / "scripts"))
        for row in preparation["source_files"]:
            need(digest(args.grant_root / row["path"]) == row["sha256"], "Existing Grant harness/source lock differs")
        contract = importlib.import_module("compile_acceptance_contract")
        source_verifier = importlib.import_module("verify_compile_acceptance")
        need(source_verifier.source_input_inventory(args.grant_root)[1] == preparation["source_tree_sha256"],
             "Complete default Grant source and frozen dependency tree must match the prepared source")
        selected = next(row for row in preparation["fixtures"]
                        if row["model_count"] == 300 and row["workload"] == args.workload)
        fixture_root = args.preparation.parent
        source = fixture_root / selected["path"]
        need(digest(source) == selected["sha256"], "The exact original representative fixture is required")
        cache = args.output / "cold-cache"
        cache.mkdir()
        need(list(cache.iterdir()) == [], "The compiler cache must begin physically empty")
        environment = dict(profile["compiler_environment"], HOME=str(args.output), TMPDIR=str(args.output),
            CRYSTAL_CACHE_DIR=str(cache), CRYSTAL_WORKERS="1", LC_ALL="C", NO_COLOR="1")
        before = alone(budget, provider)
        report["before"] = budget.asdict(before)
        binary = args.output / "fixture"
        command = contract.compile_command([profile["compiler_wrapper"]], str(source), str(binary), "debug")
        build = run_command(command, environment, args.grant_root, args.output, "build", 900)
        report["commands"].append(build)
        report["compiler_color"] = "RED" if build["exit_code"] else "YELLOW" if re.search(
            r"\bwarning\b", (args.output / "build.stdout.txt").read_text() +
            (args.output / "build.stderr.txt").read_text(), re.IGNORECASE) else "GREEN"
        need(build["exit_code"] == 0 and not build["timed_out"] and not build["raw_output_budget_exceeded"]
             and report["compiler_color"] == "GREEN" and binary.is_file(), "Actual complete GREEN code generation and linking required")
        need(0 < build["wait4_maximum_rss_bytes"] < STRICT_BYTES, "Compiler RSS conservative bound exceeds the strict budget")
        after_build = alone(budget, provider)
        report["build_window"] = budget.compare_snapshots(before, after_build, provider.limits)
        report["binary"] = artifact(binary)
        labels = ["normal", "field-canary"] + (["association-canary"] if args.workload.endswith("and_associations") else [])
        for label in labels:
            run_environment = dict(environment,
                GRANT_COMPILE_ACCEPTANCE_DATABASE_URL="sqlite3:" + str(args.output / (label + ".sqlite")),
                GRANT_COMPILE_ACCEPTANCE_INJECT_INVALID_FIRST_NAME="1" if label == "field-canary" else "0",
                GRANT_COMPILE_ACCEPTANCE_INJECT_INVALID_ASSOCIATION_FIRST_NAME="1" if label == "association-canary" else "0")
            run = run_command([str(binary)], run_environment, args.grant_root, args.output, label, 120)
            report["commands"].append(run)
            need(not run["timed_out"] and not run["raw_output_budget_exceeded"], "Actual executable must finish within its declared controls")
            if label == "normal":
                need(run["exit_code"] == 0, "Every model's ordinary runtime behavior must pass")
                save(args.output / "BEHAVIOR.json", read_behavior(args.output / (label + ".stdout.txt"), contract, 300, args.workload))
            else:
                expected = "AcceptancePerson0000 field first_name" if label == "field-canary" else "AcceptancePerson0000 parent model identity"
                need(run["exit_code"] != 0 and expected in (args.output / (label + ".stderr.txt")).read_text(),
                     "The same binary must reject the actual targeted corrupted database row")
            alone(budget, provider)
            need(artifact(binary) == report["binary"], "All runtime controls must execute the exact same binary")
        verify_files(profile)
        need(source_verifier.source_input_inventory(args.grant_root)[1] == preparation["source_tree_sha256"],
             "Complete default Grant source and frozen dependency tree changed during execution")
        report["source_tree_sha256_after"] = preparation["source_tree_sha256"]
        need(digest(source) == selected["sha256"], "The fixture remains identical after actual execution")
        report["observation_passed"] = True
    except Exception as error:
        report["errors"].append(type(error).__name__ + ": " + str(error))
    finally:
        if budget is not None:
            try:
                # Raw failure counters survive even when the strict provider refuses.
                report["final_raw_kernel_snapshot"] = budget.asdict(budget.read_snapshot(
                    lambda name: budget.read_small(Path("/sys/fs/cgroup") / name)))
                report["final_members"] = budget.read_small("/sys/fs/cgroup/cgroup.procs", 16384)
            except Exception as error:
                report["errors"].append("final kernel observation: " + str(error))
                report["observation_passed"] = False
        report["external_terminal_inspection_and_exact_container_removal"] = "required-pending"
        report["private_cache_cleanup"] = "host-removes-after-exact-container-absence"
        save(args.output / "BUILD_OBSERVATION.json", report)
    print(json.dumps({key: report[key] for key in ("observation_passed", "target_cell_accepted", "compiler_color", "errors")}))
    return 0 if report["observation_passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
