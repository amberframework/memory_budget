#!/usr/bin/env python3
"""Emit reviewable Docker argv for parent-owned hosted execution."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from build_in_cgroup import verify_profile

IMAGE = "python:3.12.10-slim@sha256:fd95fa221297a88e1cf49c55ec1828edd7c5a428187e67b5d1805692d11588db"


def commands(roots, profile, token):
    verify_profile(profile)
    if re.fullmatch("[0-9]+-[0-9]+", token or "") is None:
        raise ValueError("Exact GitHub run/attempt token required")
    for key, value in roots.items():
        if key in ("profile_sha256", "preparation_sha256"):
            if re.fullmatch("[0-9a-f]{64}", value or "") is None:
                raise ValueError("Exact reviewed profile hash required")
            continue
        if not Path(value).is_absolute() or any(character in value for character in (",", "\0", "\n", "\r")):
            raise ValueError("Literal absolute physical mount paths required")
    name = "atlas-grant-300-sqlite-debug-" + token
    docker = ["/usr/bin/docker", "--host", "unix:///var/run/docker.sock", "--config", roots["docker_config"]]
    mounts = [("/usr", "/usr", True), ("/home/linuxbrew/.linuxbrew", "/home/linuxbrew/.linuxbrew", True),
        ("/etc/ld.so.cache", "/etc/ld.so.cache", True), ("/etc/ld.so.conf", "/etc/ld.so.conf", True),
        ("/etc/ld.so.conf.d", "/etc/ld.so.conf.d", True),
        (roots["grant"], "/grant", True), (roots["provider"], "/provider", True),
        (roots["proposal"], "/proposal", True), (roots["fixtures"], "/fixtures", True),
        (roots["profile"], "/profile.json", True), (roots["evidence"], "/evidence", False)]
    create = docker + ["create", "--name", name, "--label", "org.amberframework.atlas.run=" + token,
        "--label", "org.amberframework.atlas.cell=linux-amd64-sqlite-300-associations-debug-1",
        "--network", "none", "--cpus", "1", "--memory", "1999998976", "--memory-swap", "1999998976",
        "--pids-limit", "64", "--cgroupns", "private", "--read-only", "--cap-drop", "ALL",
        "--security-opt", "no-new-privileges", "--user", "501:501", "--workdir", "/grant"]
    for source, target, readonly in mounts:
        create += ["--mount", "type=bind,src=" + source + ",dst=" + target + (",readonly" if readonly else "")]
    create += [IMAGE, "/usr/bin/python3", "-I", "-S", "-B", "/proposal/build_in_cgroup.py",
        "--profile", "/profile.json", "--profile-sha256", roots["profile_sha256"],
        "--provider-root", "/provider", "--grant-root", "/grant", "--preparation", "/fixtures/PREPARATION.json",
        "--preparation-sha256", roots["preparation_sha256"],
        "--output", "/evidence/build"]
    return {"format": "atlas-grant-linux-first-build-dispatch-plan-v1", "ready_for_execution": False,
        "actual_target_cells_accepted": 0, "container_name": name, "image": IMAGE,
        "create": create, "start": docker + ["start", name], "wait": docker + ["wait", name],
        "terminal_inspect": docker + ["inspect", name], "complete_raw_logs": docker + ["logs", name],
        "owned_removal_after_identity_check": docker + ["rm", "--force", name],
        "absence_readback": docker + ["ps", "--all", "--no-trunc", "--filter", "name=^/" + name + "$", "--format", "{{.ID}}"],
        "admission": "Parent binds actual container ID/labels, reviewed runner and native projection, fresh outputs, physical disk capacity, bounded complete timeout and finally cleanup before dispatch",
        "memory_scope": "Fresh container cgroup charge includes supervisor, compiler and all link/runtime descendants; host-precharged executable/source file-cache pages retain the separately qualified shared-charge boundary",
        "timeout_seconds": 1500, "private_cache_removal": "After exact owned container absence and external terminal verification"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", type=Path, required=True)
    parser.add_argument("--profile-sha256", required=True)
    parser.add_argument("--roots", type=Path, required=True)
    parser.add_argument("--preparation-sha256", required=True)
    parser.add_argument("--token", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if hashlib.sha256(args.profile.read_bytes()).hexdigest() != args.profile_sha256:
        raise ValueError("Actual reviewed profile hash differs")
    roots = json.loads(args.roots.read_text())
    roots["profile_sha256"] = args.profile_sha256
    roots["preparation_sha256"] = args.preparation_sha256
    args.output.write_text(json.dumps(commands(roots, json.loads(args.profile.read_text()), args.token), indent=2) + "\n")


if __name__ == "__main__":
    main()
