"""Source-only validator controls; actual native process/kernel controls follow in CI."""
import copy
import hashlib
import importlib
import json
from pathlib import Path
import sys
import tarfile
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
sys.path.insert(0, str(WORK / "grant/scripts"))
sys.path.insert(0, str(WORK / "linux_whole_build_ci_v100/checkout/tools/installation_provenance"))
import compile_acceptance_contract as contract
import cgroup_budget as budget
from verify_compile_acceptance import source_input_inventory
from prepare_first_build import archive_source
from compose_dispatch import commands as compose_dispatch
from build_in_cgroup import verify_profile
from validate_observation import validate


def artifact(path):
    return {"path": path.name, "bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


class FirstBuildControls(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.preparation = json.loads((HERE / "prepared/PREPARATION.json").read_text())
        self.profile = {"compiler_wrapper": "/home/linuxbrew/.linuxbrew/bin/crystal-alpha"}
        self.behavior = json.loads((HERE / "prepared/sqlite-300-all_model_queries_and_associations.json").read_text())["expected_behavior"]
        self.snapshot = {"memory_max": 1999998976, "memory_current": 32 * 2**20,
            "memory_peak": 1999998976, "swap_max": 0, "swap_current": 0,
            "cpu_max": "100000 100000\n", "cpu_burst": 0, "pids_max": 64, "pids_current": 1,
            "memory_events": {"low": 0, "high": 0, "max": 0, "oom": 0, "oom_kill": 0}}
        self.report = {"format": "atlas-grant-first-linux-build-observation-v1", "observation_passed": True,
            "errors": [], "target_cell_accepted": False, "full_matrix_accepted": False,
            "actual_target_cells_accepted": 0, "compiler_color": "GREEN", "commands": [],
            "source_tree_sha256_before": self.preparation["source_tree_sha256"],
            "source_tree_sha256_after": self.preparation["source_tree_sha256"],
            "build_window": {"scope": "current-cgroup-and-descendants-through-final-snapshot-v1",
                "limits": {"strict_memory_bytes": 2000000000, "page_size": 4096, "cpu_quota": 100000,
                           "cpu_period": 100000, "maximum_processes": 64},
                "before": copy.deepcopy(self.snapshot), "after": copy.deepcopy(self.snapshot)},
            "final_raw_kernel_snapshot": copy.deepcopy(self.snapshot), "final_members": "1\n",
            "external_terminal_inspection_and_exact_container_removal": "required-pending"}
        for label, exit_code, output in (("build", 0, ""), ("normal", 0, ""),
             ("field-canary", 1, "AcceptancePerson0000 field first_name\n"),
             ("association-canary", 1, "AcceptancePerson0000 parent model identity\n")):
            stdout, stderr = self.root / (label + ".stdout.txt"), self.root / (label + ".stderr.txt")
            stdout.write_text("GRANT_COMPILE_ACCEPTANCE_BEHAVIOR=" + json.dumps(self.behavior) + "\n" if label == "normal" else "")
            stderr.write_text(output)
            self.report["commands"].append({"direct_pid": 10 + len(self.report["commands"]),
                "exit_code": exit_code, "timed_out": False, "raw_output_budget_exceeded": False,
                "stdout": artifact(stdout), "stderr": artifact(stderr),
                "arguments": ["/evidence/build/fixture"]})
        self.report["commands"][0].update(arguments=[self.profile["compiler_wrapper"], "build", "--no-color",
            "-Dwithout_mt", "--threads", "1", "/fixtures/sqlite-300-all_model_queries_and_associations.cr",
            "-o", "/evidence/build/fixture"], wait4_maximum_rss_bytes=1999999999)
        (self.root / "fixture").write_bytes(b"synthetic source-only binary identity fixture\x00")
        self.report["binary"] = artifact(self.root / "fixture")

    def tearDown(self):
        self.temporary.cleanup()

    def replay(self):
        return validate(self.report, self.root, self.profile, self.preparation, contract, budget)

    def test_normal_source_fixture_replays_as_observation(self):
        self.assertEqual(self.replay(), {"observation_replayed": True, "target_cell_accepted": False, "required_matrix_size": 144})

    def test_strict_byte_boundary_and_typed_metrics(self):
        for value in (2000000000, 2000000001, 0, -1, True, 1.5, float("nan"), float("inf")):
            with self.subTest(value=value):
                self.report["commands"][0]["wait4_maximum_rss_bytes"] = value
                with self.assertRaises((ValueError, TypeError, KeyError)):
                    self.replay()

    def test_kernel_budget_and_failure_counter_controls(self):
        for key, value in (("memory_peak", 2000000000), ("memory_max", 2000000000),
                           ("swap_current", 1), ("pids_current", 2), ("cpu_max", "max 100000\n"),
                           ("memory_events", {}), ("memory_events", {"low": 0, "high": 0, "max": 0, "oom": 1, "oom_kill": 1})):
            with self.subTest(key=key, value=value):
                self.report["final_raw_kernel_snapshot"] = dict(self.snapshot, **{key: value})
                with self.assertRaises((ValueError, RuntimeError, TypeError, KeyError)):
                    self.replay()

    def test_missing_duplicate_or_forged_behavior(self):
        for operation in ("missing-model", "duplicate-model", "missing-field", "missing-edge", "forged-count"):
            with self.subTest(operation=operation):
                behavior = copy.deepcopy(self.behavior)
                if operation == "missing-model":
                    behavior["list_of_models"].pop()
                elif operation == "duplicate-model":
                    behavior["list_of_models"][-1] = behavior["list_of_models"][0]
                elif operation == "missing-field":
                    behavior["list_of_field_checks"].pop()
                elif operation == "missing-edge":
                    behavior["list_of_association_edges"].pop()
                else:
                    behavior["model_count"] = 500
                path = self.root / "normal.stdout.txt"
                path.write_text("GRANT_COMPILE_ACCEPTANCE_BEHAVIOR=" + json.dumps(behavior) + "\n")
                self.report["commands"][1]["stdout"] = artifact(path)
                with self.assertRaises(ValueError):
                    self.replay()

    def test_missing_or_reordered_actual_commands(self):
        for value in (self.report["commands"][:-1], list(reversed(self.report["commands"]))):
            with self.subTest(count=len(value)):
                report = copy.deepcopy(self.report)
                report["commands"] = value
                with self.assertRaises(ValueError):
                    validate(report, self.root, self.profile, self.preparation, contract, budget)

    def test_same_binary_canaries_reject_false_success(self):
        for index in (2, 3):
            report = copy.deepcopy(self.report)
            report["commands"][index]["exit_code"] = 0
            with self.assertRaises(ValueError):
                validate(report, self.root, self.profile, self.preparation, contract, budget)

    def test_retired_writers_and_unchanged_artifacts(self):
        self.report["final_members"] = "1\n5\n"
        with self.assertRaises(ValueError):
            self.replay()
        self.report["final_members"] = "1\n"
        (self.root / "fixture").write_bytes(b"different executable")
        with self.assertRaises(ValueError):
            self.replay()

    def test_warning_and_changed_compiler_command_reject(self):
        path = self.root / "build.stderr.txt"
        path.write_text("Warning: changed compile behavior\n")
        self.report["commands"][0]["stderr"] = artifact(path)
        with self.assertRaises(ValueError):
            self.replay()
        path.write_text("")
        self.report["commands"][0]["stderr"] = artifact(path)
        self.report["commands"][0]["arguments"].insert(1, "--no-codegen")
        with self.assertRaises(ValueError):
            self.replay()

    def test_observation_cannot_claim_final_acceptance(self):
        self.report["target_cell_accepted"] = True
        with self.assertRaises(ValueError):
            self.replay()

    def test_complete_original_rosters_and_144_cells(self):
        self.assertEqual(len(self.preparation["required_target_cells"]), 144)
        self.assertEqual(len(set(self.preparation["required_target_cells"])), 144)
        for row in self.preparation["fixtures"]:
            count, workload = row["model_count"], row["workload"]
            self.assertEqual(row["operations"], count * 3)
            self.assertEqual(row["field_checks"], count * 16)
            self.assertEqual(row["association_edges"], count * 3 if workload.endswith("and_associations") else 0)
            manifest = json.loads((HERE / "prepared" / row["manifest"]).read_text())
            contract.verify_behavior(manifest["expected_behavior"], count, workload)

    def test_unadmitted_runtime_projection_refuses(self):
        profile = {"format": "atlas-grant-linux-build-integration-profile-v1", "platform": "linux-amd64",
            "ordinary_alpha_installation_ready": True, "readiness_receipt_sha256": "a" * 64,
            "runtime_projection_reviewed": False, "files": []}
        with self.assertRaisesRegex(ValueError, "runtime projection"):
            verify_profile(profile)

    def test_physical_source_archive_replays_and_is_deterministic(self):
        archive_path = HERE / "prepared/grant-source-and-frozen-dependencies.tar.gz"
        repeat = self.root / "repeat.tar.gz"
        inventory, identity = source_input_inventory(WORK / "grant")
        archive_source(WORK / "grant", repeat, inventory)
        self.assertEqual(artifact(repeat)["sha256"], artifact(archive_path)["sha256"])
        extracted = self.root / "extracted"
        extracted.mkdir()
        with tarfile.open(archive_path, "r:gz") as archive:
            for member in archive.getmembers():
                self.assertFalse(Path(member.name).is_absolute())
                self.assertTrue(member.name.startswith("grant/"))
                self.assertNotIn("..", Path(member.name).parts)
                self.assertTrue(member.isdir() or member.isfile() or member.issym())
                if member.issym():
                    target = (extracted / member.name).parent / member.linkname
                    self.assertTrue(target.resolve().is_relative_to((extracted / "grant").resolve()))
            archive.extractall(extracted)
        self.assertEqual(source_input_inventory(extracted / "grant")[1], identity)

    def test_dispatch_retains_real_budget_and_original_full_fixture(self):
        profile = {"format": "atlas-grant-linux-build-integration-profile-v1", "platform": "linux-amd64",
            "ordinary_alpha_installation_ready": True, "readiness_receipt_sha256": "a" * 64,
            "runtime_projection_reviewed": True, "compiler_wrapper": "/fake/wrapper", "compiler_backend": "/fake/backend",
            "compiler_environment": {"PATH": "/usr/bin:/bin"},
            "files": [{"path": path, "sha256": "b" * 64} for path in (
                "/fake/wrapper", "/fake/backend", "/usr/bin/python3.12", "/usr/bin/gcc", "/usr/bin/ld", "/fake/libgmp.so")]}
        roots = {key: "/source-fixture/" + key for key in (
            "docker_config", "grant", "provider", "proposal", "fixtures", "profile", "evidence")}
        roots["profile_sha256"] = "c" * 64
        roots["preparation_sha256"] = "d" * 64
        plan = compose_dispatch(roots, profile, "1234-1")
        self.assertFalse(plan["ready_for_execution"])
        self.assertEqual(plan["create"][plan["create"].index("--memory") + 1], "1999998976")
        self.assertIn("/proposal/build_in_cgroup.py", plan["create"])
        self.assertIn("/fixtures/PREPARATION.json", plan["create"])
        self.assertIn("--read-only", plan["create"])
        self.assertEqual(plan["create"][plan["create"].index("--cpus") + 1], "1")
        self.assertEqual(plan["create"][plan["create"].index("--user") + 1], "501:501")
        self.assertTrue(any("dst=/grant,readonly" in value for value in plan["create"]))
        self.assertTrue(any("dst=/usr,readonly" in value for value in plan["create"]))


if __name__ == "__main__":
    unittest.main()
