# First representative Grant build on hosted Linux

Mission: `memory-budget-experiment`. This source-only integration proposal advances the original [144-cell contract](../../atlas-program/grant_acceptance_contract.json). Its first selected build is **Linux amd64 / SQLite / 300 models / all queries and associations / debug / cold repetition 1**. The strict compiler and whole-build budgets remain **less than 2,000,000,000 bytes**. Accepted target cells remain **0/144**.

The package uses the existing rich Grant generator and exact frozen source closure. It imports the accepted `cgroup_budget.py` implementation and its snapshot/limit validation directly. Its additional Python files connect that existing provider to an actual compiler invocation and the existing executed Grant behavior reader. The existing kernel descendant, concurrent RSS, detached-worker, sibling, and shared-page controls retain their original scopes.

## What is executable now

The parent can run source preparation and its unit/physical-archive checks immediately:

```sh
PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 -B \
  .luna/atlas-work/grant_linux_first_build_v100/prepare_first_build.py \
  --grant-root .luna/atlas-work/grant \
  --provider-root .luna/atlas-work/linux_whole_build_ci_v100/checkout \
  --program-contract .luna/atlas-program/grant_acceptance_contract.json \
  --output <fresh-output-directory>

PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 -B -m unittest discover \
  -s .luna/atlas-work/grant_linux_first_build_v100 -p 'test_first_build.py' -v
```

Actual preparation generated all four SQLite fixtures: 300 and 500 models, each with queries alone and queries plus associations. The 300-model association fixture retains **900 create/hydrate/scope operations, 4,800 field checks, and 900 direct/reverse/eager association checks**. The 500-model association fixture retains 1,500 operations, 8,000 field checks, and 1,500 edges. The full default Grant entry point remains required. The query-only fixtures preserve their original empty association roster; the association cells remain separate required cells.

The deterministic source/dependency archive is **1,626,007 bytes**, SHA-256 **`d2c90cc3110109337c92f567fdf533dadf475b3f468602b8fcb5e2ed21426ff5`**. A physical extraction and independent call to the existing source inventory reproduce the original **1,554-row** source identity **`edeb868d76119f67dacdd829a0113ba0b0637583f0ee2fcbd87078a6cbee9d8a`**. A second fresh archive has the same digest. This package preserves the already frozen dependency sources; a fresh ordinary `shards-alpha install --frozen` remains its own installation acceptance step.

Thirteen executed source-only test groups pass, including strict byte boundaries, nonfinite/type refusals, incomplete/duplicate/forged model and edge rosters, altered argv, warnings, changed binaries, false-success runtime canaries, surviving descendants, kernel counters, deterministic archive replay, and exact Docker plan limits. Their synthetic observation is clearly an input-validation fixture. Actual Linux compiler, kernel integration, native projection, and runtime canaries remain unexecuted here.

## Implementation stack and actual commands

1. **Normal installation**: use the public Alpha tap's existing Homebrew source install and installer round trip, then its SDK readiness step. Alpha release source remains `9c1e8ec64f6be6343e90d3979bc9536c4b050292`, version `1.21.0-incremental-1`, source archive SHA-256 `2c85084ce5ed4973d7f1f73987ba990b7b16381f60dd8ccc8a92b2bec1203b05`; the reviewed formula SHA-256 is `7ce1726c8c792836ec6e84013a1906c800dfaefc30954e96f0974a6bf17ab5f7`. The existing Linux installed-stdlib mismatch in run39466185998 is a real prerequisite failure. The first target build follows successful actual installation readiness and independently reviewed native-profile derivation.
2. **Compiler/dependency source**: use `prepared/grant-source-and-frozen-dependencies.tar.gz`, verified against `PREPARATION.json`, and preserve its symlinks and file modes. The package includes precisely the existing compiler-input roots and excludes the checkout's root environment file. Extract to a host staging directory and mount the extracted `grant` root read-only at `/grant`. Mount `prepared` read-only at `/fixtures`.
3. **Kernel provider**: use SDK source `372bc3379c07c8e75ba92cb6d8a40e57ecbb8bfe`, installation-provider manifest `15e27eea749e5d08f7d41256515b078f256c89fed5c49647c09dc99b99406eae`, and whole-build probe manifest `233f9658ccd015e2c9e7c268723963ed3713dbb2fc4a552f65d2b52a13288cfd`. Read the actual hosted runner with its existing `record_linux_runner.py`; match one exact reviewed profile before creating a container. Current profile source is in `SOURCE_IDENTITIES.json`.
4. **Native runtime projection**: the container runs the actual ordinary installed Alpha wrapper and backend. `compose_dispatch.py` proposes mounting the host's Ubuntu `/usr`, Linuxbrew prefix, and loader configuration read-only into the existing digest-pinned container. That preserves the installed Ubuntu tool ABI rather than attempting to run it with the base Debian image's older libc. The image remains `python:3.12.10-slim@sha256:fd95fa221297a88e1cf49c55ec1828edd7c5a428187e67b5d1805692d11588db`. The Ubuntu process/loader/native/header projection requires actual qualification; it is the main concrete integration gap after the current readiness failure. The compiler and dependency closure must be checked before and after the build. The future accepted profile must include required GMP, SQLite, OpenSSL, GC, C compiler/linker, loader, and their actual transitive inputs.
5. **Actual build and behavior**: `build_in_cgroup.py` is a non-root PID-1 supervisor. It calls the unchanged existing complete-build command helper with `--no-color -Dwithout_mt --threads 1`, `CRYSTAL_WORKERS=1`, an initially empty private cache, full code generation/linking, and the original generated source. Its build command has a 900-second limit; each runtime command has 120 seconds; the external host owns a 1,500-second full interval and finally cleanup. A 4-KiB-page container uses the provider-derived **1,999,998,976-byte** ceiling, equal memory/swap limits, one CPU, and 64 process slots. The provider also checks actual page size and refuses a mismatching ceiling. Normal execution must report every model, field, operation and required edge. The exact same resulting binary then runs with a deliberately corrupted field and corrupted association target; both must fail at the named original assertion.
6. **Replay and cleanup**: `validate_observation.py` uses the original Grant behavior reader and original typed kernel snapshots to replay actual raw artifacts, complete argv, normal behavior, canaries, strict peaks, terminal membership and source identity. The host retains actual Docker ID, complete inspect/image/mount/command evidence and logs, performs the separately required external terminal validation, removes the exact owned container, and reads back its absence. Private cache removal follows confirmed writer retirement. Every failure preserves the raw evidence and the target remains failed/incomplete.

The compiler RSS observation is Linux `wait4`'s largest direct-or-waited-descendant high-water mark. It is a conservative bound on the compiler's RSS, and its qualification needs an actual compiler and helper comparison. It is **separate from concurrent cgroup charged memory**. The cgroup metric includes the supervisor and every contained descendant, plus charged cache/kernel pages. Read-only host source and executable mappings can retain the already demonstrated host-precharged shared-file boundary. The first result must name both quantities and preserve these boundaries.

With reviewed mounted roots and the actual reviewed profile hash, the parent can produce exact Docker argv:

```sh
python3 -I -S -B compose_dispatch.py \
  --profile /actual/reviewed-linux-build-profile.json \
  --profile-sha256 <independently-reviewed-actual-profile-sha256> \
  --preparation-sha256 <reviewed-PREPARATION.json-sha256> \
  --roots /actual/mount-roots.json \
  --token <github-run-id>-<attempt> \
  --output /actual/dispatch-plan.json
```

`mount-roots.json` supplies absolute physical paths for `docker_config`, `grant`, `provider`, `proposal`, `fixtures`, `profile`, and `evidence`. The plan has complete create/start/wait/inspect/log/removal/absence argv, the fixed budget and image, and explicit parent admission. Plan emission carries `ready_for_execution: false`: it is a reviewable command proposal, while the parent owns the actual physical/profile/resource/cleanup admission. The existing `verify_terminal.py` is specifically tied to its four original control commands and mount roster; it must be extended with a separate first-build case, retaining every old control, before this new projection can earn complete-build acceptance.

Inside that admitted container the concrete command is:

```sh
/usr/bin/python3 -I -S -B /proposal/build_in_cgroup.py \
  --profile /profile.json --profile-sha256 <reviewed-sha256> \
  --provider-root /provider --grant-root /grant \
  --preparation /fixtures/PREPARATION.json \
  --preparation-sha256 <reviewed-PREPARATION.json-sha256> --output /evidence/build
```

The actual compiler invocation is:

```sh
<ordinary-installed-crystal-alpha-wrapper> build --no-color -Dwithout_mt \
  --threads 1 /fixtures/sqlite-300-all_model_queries_and_associations.cr \
  -o /evidence/build/fixture
```

## Exact remaining gaps

| Gap | Concrete next action and required evidence |
| --- | --- |
| Ordinary Linux installation readiness | Repair the actual installed-stdlib source mismatch; run actual SDK/default/without_mt/tutorial controls with the installed compiler, preserving the failed run. |
| Runtime projection | Record actual ordinary Alpha wrapper/backend, stdlib, native libraries and C toolchain closure; independently review those exact bytes and the `/usr`/Linuxbrew/loader mounts; execute loader, compiler, SQLite/GMP and link canaries inside the proposed container. |
| Complete-build external reader | Add a separately named case to the existing terminal validation for this exact command, image, ID/labels, mount permissions and strict budget. Preserve old provider tests and add changed-inspect refusal controls. |
| Actual process/compiler qualification | Execute the first real compiler wrapper/linker inside this boundary, record kernel before/build/final snapshots, direct wait4 RSS, contained helpers and final supervisor-only membership. Cross-check conservative RSS with the qualified native controls. Actual migration and any writable-controller escape remain explicit provider acceptance questions. |
| Real budget and functional controls | Execute normal, corrupt-field and corrupt-association same-binary paths. Execute a deliberately lower finite memory ceiling against the same compiled fixture/build and preserve real kernel failure plus terminal cleanup. A 2-GB OOM is a failed target observation with a lower bound, not a passed peak. Exit137 alone supplies insufficient OOM provenance. |
| Source/dependency installation distribution | Put the exact package and proposal on the parent's public review branch and verify published bytes. Run actual fresh frozen dependency installation separately before claiming normal dependency/device installation acceptance. |
| First target result | Run the full original 300-model association debug fixture. Its current feasibility is unproven. Preserve complete output if it exceeds the hard ceiling. Remaining143 cells stay required; query-only,500-model,release,Pg,MySQL,Darwin and cold repetitions retain their identities. |

## Review and scope

Crystal conventions and the complete review rubric were read before fixture review. The existing Crystal generator/source was reused byte-for-byte, so Crystal MAJOR1–15b are **not applicable to new Crystal edits**; no new Crystal application source or feature setting was authored. The generated fixture includes existing JSON::Serializable output and the existing default Grant/adapter entry points. This proposal's policy is in its own JSON/tooling files. Its Python tests are source/reader controls. Crystal formatting, lint/LSP, actual compiler GREEN and runtime behavior are **pending**, with actual compiler jobs0. The existing manifest's `ai_docs` tooling key and broader original source review remain inherited source facts rather than a new configuration precedent.

The first preparation attempt refused an overly narrow per-package symlink rule because ordinary frozen dependency `lib` aliases point at the common dependency root. The corrected source verifies that aliases remain inside the complete pinned closure and independently replays the physical archive. Both earlier preparation outputs remain preserved. A physical archive test also exposed macOS `/var` to `/private/var` path alias normalization; its comparison now uses physical resolved paths.
