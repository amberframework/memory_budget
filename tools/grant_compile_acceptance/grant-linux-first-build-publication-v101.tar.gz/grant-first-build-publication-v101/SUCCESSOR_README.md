# Grant publication compatibility successor v101

Mission: **memory-budget-experiment**. This is a source/package compatibility successor. Corrected hosted execution and every compiler, container, native-target, SSH, customer/release, and full-build gate remain pending. The original target remains **0/144**.

The exact v100 outer packet is retained at `ancestry/grant-linux-first-build-publication-v100.tar.gz` (2,908,563 bytes, SHA-256 `aebd690e5978aa6373e2177aa7ee2d5bcb8b7e064cc50aee18ae9c4d53fc5601`). The unchanged inner Grant/frozen-dependency archive remains 1,626,007 bytes, SHA-256 `d2c90cc3110109337c92f567fdf533dadf475b3f468602b8fcb5e2ed21426ff5`. Its full maintained workload, fixtures, contracts, source origins, frozen audit findings, and original v100/v102 tests remain exact.

The original [hosted run 39480858638](https://github.com/amberframework/memory_budget/actions/runs/39480858638) failed on both platforms. Ubuntu reproduced the exact archives and then failed while reading optional `zlib.__file__` metadata. macOS 3.15 produced the same tar bytes with gzip's changed default level 6. The retained evidence at `ancestry/HOSTED_V100_EVIDENCE.json` binds both ZIP digests, raw refusal receipts, and the anonymous exact public-archive readback.

Active v101 verifier and builder paths require gzip compression level **9** explicitly. The active runner uses `PORTABLE_HELPER_COMPATIBILITY.v101.json` to map a fresh workspace's preparation-helper import to the named v102 portable helper. The original helper, preceding portable helper, original mapping, and original tests remain exact. Historical v100 tools retain their original behavior as source ancestry.

Provider admission requires an exact reviewed interpreter version and executable SHA-256. A built-in `zlib` requires matching module/spec names, the built-in origin, and the built-in module-name roster. It records a null module-file hash with an explicit interpreter-code scope. A file-backed module retains its regular-file identity and SHA-256. Both record compile/runtime versions and preserve full native closure as a separate gate.

The runner executes the unchanged **13 v100 + 16 v102** tests in ordinary and optimized modes, plus **12** successor controls in both modes. Each of the six serial source cohorts has a 75-second deadline, totaling 450 seconds inside the workflow's 540-second wrapper bound. Physical controls simulate a default gzip level of 6 for inner, outer, and mapped-helper writers; provider controls exercise built-in/file-backed metadata and altered-layout/interpreter refusals.

Use the parent-reviewed exact interpreter/source/manifest hashes before executing any manual command. The checked public workflow provides complete pre-execution admission and preserves raw output and original errors. Local Xcode 3.9.6 is a local source-review profile; hosted Linux 3.12.3 and macOS 3.15.0 are distinct recorded interpreter profiles. A local source pass establishes its exact local scope.

To reproduce the envelope after hash admission, execute `tools/build_publication_v101.py` with the exact `--ancestor`, `--sources successor_source`, independently declared `--source-pins-sha256`, and a fresh `--output` path. The named builder preserves every original payload member and the frozen packet, derives the successor contents manifest, and uses the active explicit-level verifier archive writer.

All original scientific, full-native, customer/release, and full Grant acceptance boundaries remain in force. Successful source controls establish source/package behavior for their actual provider; actual hosted and build receipts establish their own later gates.
