#!/usr/bin/env python3
"""Physical compression controls and checked provider-layout regressions."""
import gzip
import hashlib
import importlib.machinery
import importlib.util
from pathlib import Path
import shutil
import sys
import tarfile
import tempfile
import types
import unittest
from unittest import mock


HERE = Path(__file__).resolve().parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


verifier = load("regression_verifier_v101", HERE / "tools/verify_publication_v101.py")
portable = load("regression_portable_v102", HERE / "portable/prepare_first_build_portable_v102.py")


class PublicationCompatibilityControl(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="Grant publication source control ")
        self.root = Path(self.temporary.name)
        self.addCleanup(self.temporary.cleanup)

    def simulated_default_six(self, target):
        observed = []
        original = gzip.GzipFile

        def gzip_file(*args, **kwargs):
            observed.append(kwargs.setdefault("compresslevel", 6))
            return original(*args, **kwargs)
        return mock.patch.object(target, "gzip", types.SimpleNamespace(GzipFile=gzip_file)), observed

    def zlib_module(self, origin="built-in", path=None):
        module = types.SimpleNamespace(__name__="zlib",
            __spec__=importlib.machinery.ModuleSpec("zlib", loader=None, origin=origin),
            ZLIB_VERSION="1.2.13", ZLIB_RUNTIME_VERSION="1.2.13")
        if path is not None:
            module.__file__ = str(path)
        return module

    def test_inner_rebuild_explicit_level_nine_survives_default_six(self):
        with tarfile.open(HERE / verifier.INNER_PATH, "r:gz") as archive:
            members = archive.getmembers()
        context, observed = self.simulated_default_six(verifier)
        target = self.root / "inner.tar.gz"
        with context:
            verifier.rebuild_from_members(Path.cwd(), members, target)
        self.assertEqual(observed, [9])
        self.assertEqual(verifier.sha(target), verifier.INNER_SHA)

    def test_outer_rebuild_explicit_level_nine_survives_default_six(self):
        contents = verifier.parse((HERE / "PACKAGE_CONTENTS.json").read_bytes())
        target = self.root / "outer.tar.gz"
        context, observed = self.simulated_default_six(verifier)
        with context:
            verifier.rebuild_outer(HERE, contents, target)
        self.assertEqual(observed, [9])
        self.assertEqual(target.read_bytes()[:10].hex(), "1f8b08000000000002ff")
        with tarfile.open(target, "r:gz") as archive:
            self.assertEqual(len(archive.getmembers()), len(contents["files"]) + len(contents["directories"]) + 1)

    def test_portable_helper_explicit_level_nine_survives_default_six(self):
        inventory = verifier.parse((HERE / "workspace/grant_linux_first_build_v100/prepared/SOURCE_INPUT_ROSTER.json").read_bytes())
        target = self.root / "portable.tar.gz"
        context, observed = self.simulated_default_six(portable)
        with context:
            portable.archive_source(Path.cwd() / "grant", target, inventory)
        self.assertEqual(observed, [9])
        self.assertEqual(verifier.sha(target), verifier.INNER_SHA)

    def test_builtin_zlib_records_origin_and_exact_interpreter(self):
        names = tuple(set(sys.builtin_module_names) | {"zlib"})
        with mock.patch.object(verifier, "zlib", self.zlib_module()), mock.patch.object(sys, "builtin_module_names", names):
            result = verifier.source_provider_metadata()
        self.assertEqual(result["zlib_module_kind"], "built-in")
        self.assertEqual(result["zlib_module_origin"], "built-in")
        self.assertIsNone(result["zlib_module_sha256"])
        self.assertEqual(result["python_sha256"], verifier.sha(Path(sys.executable).resolve()))
        self.assertFalse(result["full_native_dependency_closure_accepted"])

    def test_file_backed_zlib_retains_module_file_hash(self):
        path = self.root / "zlib-extension.fixture"
        path.write_bytes(b"Physical metadata fixture for a file-backed source module\n")
        with mock.patch.object(verifier, "zlib", self.zlib_module(str(path), path)):
            result = verifier.source_provider_metadata()
        self.assertEqual(result["zlib_module_kind"], "file-backed")
        self.assertEqual(result["zlib_module_origin"], str(path))
        self.assertEqual(result["zlib_module_sha256"], hashlib.sha256(path.read_bytes()).hexdigest())
        self.assertEqual(result["zlib_module_bytes"], path.stat().st_size)

    def test_missing_file_with_unrecognized_origin_refuses(self):
        with mock.patch.object(verifier, "zlib", self.zlib_module("frozen")):
            with self.assertRaisesRegex(ValueError, "actual built-in"):
                verifier.source_provider_metadata()

    def test_builtin_origin_with_unlisted_name_refuses(self):
        names = tuple(name for name in sys.builtin_module_names if name != "zlib")
        with mock.patch.object(verifier, "zlib", self.zlib_module()), mock.patch.object(sys, "builtin_module_names", names):
            with self.assertRaisesRegex(ValueError, "actual built-in"):
                verifier.source_provider_metadata()

    def test_file_backed_conflicting_import_origin_refuses(self):
        path = self.root / "zlib-extension.fixture"
        path.write_bytes(b"metadata fixture\n")
        with mock.patch.object(verifier, "zlib", self.zlib_module("built-in", path)):
            with self.assertRaisesRegex(ValueError, "import origin"):
                verifier.source_provider_metadata()

    def test_altered_interpreter_profile_refuses_before_extraction(self):
        profiles = {key: "0" * 64 for key in verifier.SOURCE_PYTHON_PROFILES}
        output = self.root / "altered provider output"
        with mock.patch.object(verifier, "SOURCE_PYTHON_PROFILES", profiles):
            with self.assertRaisesRegex(ValueError, "executable digest"):
                verifier.verify(HERE / "ancestry/grant-linux-first-build-publication-v100.tar.gz",
                                verifier.ANCESTOR_SHA, "unused", output)
        self.assertFalse(output.exists())

    def test_changed_archive_refuses_before_extraction(self):
        archive = self.root / "changed.tar.gz"
        raw = bytearray((HERE / "ancestry/grant-linux-first-build-publication-v100.tar.gz").read_bytes())
        raw[-1] ^= 1
        archive.write_bytes(raw)
        output = self.root / "changed output"
        with self.assertRaisesRegex(ValueError, "digest required"):
            verifier.verify(archive, verifier.ANCESTOR_SHA, "unused", output)
        self.assertFalse(output.exists())

    def test_changed_physical_payload_bytes_refuse(self):
        copy = self.root / "changed payload"
        shutil.copytree(HERE, copy)
        (copy / "SUCCESSOR_README.md").write_bytes(b"changed")
        with self.assertRaisesRegex(ValueError, "Physical payload"):
            verifier.verify_payload(copy, verifier.sha(HERE / "PACKAGE_CONTENTS.json"))

    def test_changed_physical_payload_mode_refuses(self):
        copy = self.root / "changed mode payload"
        shutil.copytree(HERE, copy)
        (copy / "SUCCESSOR_README.md").chmod(0o600)
        with self.assertRaisesRegex(ValueError, "Physical payload"):
            verifier.verify_payload(copy, verifier.sha(HERE / "PACKAGE_CONTENTS.json"))


if __name__ == "__main__":
    unittest.main()
