#!/usr/bin/env python3
"""Build a named v101 envelope while retaining the exact public v100 packet."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import stat

ANCESTOR_SHA = "aebd690e5978aa6373e2177aa7ee2d5bcb8b7e064cc50aee18ae9c4d53fc5601"
ANCESTOR_CONTENTS = "292430bfd276814ed8bfda4e0edb16aa04e582a9bc92bd927c6c4bf2a9beb9c6"
SOURCE_TARGETS = {
    "verify_publication_v101.py": "tools/verify_publication_v101.py",
    "run_source_tests_v101.py": "tools/run_source_tests_v101.py",
    "build_publication_v101.py": "tools/build_publication_v101.py",
    "test_publication_v101.py": "tools/test_publication_v101.py",
    "prepare_first_build_portable_v102.py": "portable/prepare_first_build_portable_v102.py",
    "SUCCESSOR_README.md": "SUCCESSOR_README.md",
    "HOSTED_V100_EVIDENCE.json": "ancestry/HOSTED_V100_EVIDENCE.json",
}


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, data):
    with path.open("x") as stream:
        stream.write(json.dumps(data, indent=2, sort_keys=True) + "\n")
    path.chmod(0o644)


def build(ancestor, sources, expected_sources_sha, output):
    sources = sources.resolve(strict=True)
    manifest = sources / "TOOL_SOURCE_PINS.json"
    need(sha(manifest) == expected_sources_sha, "Exact independently declared successor source manifest required")
    pins = json.loads(manifest.read_bytes())
    need(pins["format"] == "atlas-grant-publication-successor-tools-v101"
         and len(pins["files"]) == len(SOURCE_TARGETS)
         and {row["path"] for row in pins["files"]} == set(SOURCE_TARGETS),
         "Complete unique named successor tool roster required")
    before = []
    for row in pins["files"]:
        path = sources / row["path"]
        need(path.is_file() and not path.is_symlink() and stat.S_IMODE(path.stat().st_mode) == row["mode"] == 0o644
             and path.stat().st_size == row["bytes"] and sha(path) == row["sha256"],
             "Exact successor source bytes and regular-file mode required: " + row["path"])
        before.append(dict(row))
    own = next(row for row in before if row["path"] == "build_publication_v101.py")
    need(sha(Path(__file__).resolve()) == own["sha256"], "Executed builder equals the admitted source")
    verifier_path = sources / "verify_publication_v101.py"
    spec = importlib.util.spec_from_file_location("admitted_v101_builder_verifier", verifier_path)
    verifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verifier)
    provider = verifier.source_provider_metadata()
    need(ancestor.stat().st_size == 2908563 and sha(ancestor) == ANCESTOR_SHA,
         "Exact frozen public v100 archive required")
    output.mkdir(parents=True, exist_ok=False)
    ancestor_root, ancestor_contents = verifier.extract_outer(
        ancestor, output / "ancestor readback with spaces", ANCESTOR_CONTENTS,
        "grant-first-build-publication-v100")
    payload = output / "payload"
    shutil.copytree(ancestor_root, payload)
    preserved = {row["path"]: row for row in ancestor_contents["files"]}
    ancestry = payload / "ancestry"
    shutil.copyfile(payload / "PACKAGE_CONTENTS.json", ancestry / "PACKAGE_CONTENTS.original_v100.json")
    (payload / "PACKAGE_CONTENTS.json").unlink()
    shutil.copyfile(ancestor, ancestry / "grant-linux-first-build-publication-v100.tar.gz")
    for name, target in SOURCE_TARGETS.items():
        destination = payload / target
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(sources / name, destination)
        destination.chmod(0o644)
    source_copy = payload / "successor_source"
    source_copy.mkdir()
    for name in list(SOURCE_TARGETS) + ["TOOL_SOURCE_PINS.json"]:
        shutil.copyfile(sources / name, source_copy / name)
        (source_copy / name).chmod(0o644)
    mapping = verifier.parse((payload / "PORTABLE_HELPER_COMPATIBILITY.json").read_bytes())
    mapping.update({
        "publication_successor": "v101",
        "portable_source_path": "portable/prepare_first_build_portable_v102.py",
        "portable_sha256": sha(sources / "prepare_first_build_portable_v102.py"),
        "prior_portable_source_path": "portable/prepare_first_build_portable_v101.py",
        "prior_portable_sha256": "4c166386999e7c0b49236e92c01ab00672b63fc80db071f9cf27bd827a658d32",
        "gzip_compression_level": 9,
        "mapping_reason": "Explicit level 9 preserves exact original gzip bytes across Python 3.15 default-level changes",
        "original_tests_and_source_archive": "preserved exactly",
        "actual_Linux_source_test_qualification": "pending-v101-hosted",
    })
    save(payload / "PORTABLE_HELPER_COMPATIBILITY.v101.json", mapping)
    save(payload / "PACKAGE_BUILD_PROVIDER.v101.json", provider)
    save(payload / "SUCCESSOR_SCOPE.json", {
        "mission": "memory-budget-experiment",
        "publication_successor": "v101",
        "frozen_v100_outer_sha256": ANCESTOR_SHA,
        "immutable_inner_sha256": verifier.INNER_SHA,
        "source_tool_manifest_sha256": expected_sources_sha,
        "active_verifier": "tools/verify_publication_v101.py",
        "active_source_runner": "tools/run_source_tests_v101.py",
        "active_portable_helper": mapping["portable_source_path"],
        "active_builder": "tools/build_publication_v101.py",
        "preserved_v100_tools": "Historical exact source and ancestry",
        "original_v100_tests": 13, "original_v102_tests": 16,
        "new_successor_regressions": 12,
        "corrected_hosted_source_acceptance": "pending-parent-hosted",
        "ordinary_installation_native_projection_actual_build": "pending",
        "full_native_dependency_closure_accepted": False,
        "actual_compiler_container_native_ssh_jobs": 0,
        "accepted_target_cells": 0, "required_target_cells": 144,
    })
    for relative, row in preserved.items():
        path = payload / relative
        need(path.stat().st_size == row["bytes"] and sha(path) == row["sha256"]
             and stat.S_IMODE(path.stat().st_mode) == row["mode"],
             "Every original payload file remains exact: " + relative)
    need(sha(ancestry / "PACKAGE_CONTENTS.original_v100.json") == ANCESTOR_CONTENTS,
         "Exact original contents manifest retained")
    for path in [payload] + list(payload.rglob("*")):
        need(not path.is_symlink(), "Successor outer envelope contains ordinary members")
        if path.is_dir():
            path.chmod(0o755)
    files = []
    for path in sorted(payload.rglob("*")):
        if path.is_file():
            relative = path.relative_to(payload).as_posix()
            files.append({"path": relative, "bytes": path.stat().st_size,
                "mode": stat.S_IMODE(path.stat().st_mode), "sha256": sha(path),
                "origin": preserved[relative]["origin"] if relative in preserved else {
                    "role": "Named v101 source-package compatibility successor or exact v100 ancestry",
                    "source_tool_manifest_sha256": expected_sources_sha}})
    directories = [payload] + sorted(path for path in payload.rglob("*") if path.is_dir())
    contents = {"format": "atlas-grant-first-build-publication-contents-v1",
        "mission": "memory-budget-experiment", "archive_prefix": verifier.PREFIX,
        "manifest_authority": "Every other payload file; exact external archive and contents pins bind this manifest",
        "files": files,
        "directories": [{"path": "." if path == payload else path.relative_to(payload).as_posix(), "mode": 0o755}
                        for path in directories]}
    save(payload / "PACKAGE_CONTENTS.json", contents)
    archive = output / "grant-linux-first-build-publication-v101.tar.gz"
    verifier.rebuild_outer(payload, contents, archive)
    need(sha(payload / verifier.INNER_PATH) == verifier.INNER_SHA, "Original compiler source archive remains exact")
    need(sha(ancestor) == ANCESTOR_SHA, "Original publication packet remains exact")
    for row in before:
        path = sources / row["path"]
        need(sha(path) == row["sha256"] and path.stat().st_size == row["bytes"]
             and stat.S_IMODE(path.stat().st_mode) == row["mode"],
             "Successor source retains exact before/after identity")
    need(verifier.source_provider_metadata() == provider, "Source build provider retains exact identity")
    result = {"mission": "memory-budget-experiment", "local_source_package_built": True,
        "outer_archive": {"filename": archive.name, "bytes": archive.stat().st_size, "sha256": sha(archive)},
        "contents_sha256": sha(payload / "PACKAGE_CONTENTS.json"), "source_tool_manifest_sha256": expected_sources_sha,
        "frozen_v100_outer_sha256": ANCESTOR_SHA, "immutable_inner_sha256": verifier.INNER_SHA,
        "preserved_original_payload_files": len(preserved),
        "outer_files": len(files) + 1, "outer_directories": len(directories),
        "provider": provider, "public_upload_and_corrected_hosted_acceptance": "pending-parent",
        "actual_compiler_container_native_ssh_jobs": 0, "accepted_target_cells": 0, "required_target_cells": 144}
    save(output / "BUILD_RECEIPT.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ancestor", type=Path, required=True)
    parser.add_argument("--sources", type=Path, required=True)
    parser.add_argument("--source-pins-sha256", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(build(args.ancestor.resolve(), args.sources,
                           args.source_pins_sha256, args.output.resolve()), indent=2))


if __name__ == "__main__":
    main()
