# Grant first-build source publication wrapper

Mission: **memory-budget-experiment**. This package preserves the **local maintained Grant integration** at `d78418566d90e61d6876a4a2a8abd93bb74f1ba1`, with its exact frozen dependencies, generated fixture cells, source-origin evidence, and publication notices. Local source/package verification is complete when its separate verification receipt passes. Parent public commit/upload, ordinary installation, native projection, and actual compile/link/runtime qualification remain pending. Accepted target cells remain **0/144**; actual compiler/container/native/SSH jobs for this packaging work are **0**.

## Exact preserved source

`workspace/grant_linux_first_build_v100/prepared/grant-source-and-frozen-dependencies.tar.gz` is the immutable accepted v100 inner archive: **1,626,007 bytes**, SHA-256 **`d2c90cc3110109337c92f567fdf533dadf475b3f468602b8fcb5e2ed21426ff5`**. Its canonical source inventory has **1,554 rows**, identity `edeb868d76119f67dacdd829a0113ba0b0637583f0ee2fcbd87078a6cbee9d8a`. The archive has 1,549 physical payload members: 1,544 regular files and five common-dependency-root aliases. Structural directories are recorded separately in `origin/INNER_TAR_MEMBER_LEDGER.json`.

The exact Grant MIT copyright and permission notice accompanies the software at [LICENSES/GRANT_LICENSE.txt](LICENSES/GRANT_LICENSE.txt), SHA-256 `0b86f20bd913c32e463c1601c7caaf464aeee45d63f94ecf3cd4363c6997014d`. Each frozen dependency retains its own license inside the inner archive.

`PACKAGE_CONTENTS.json` records every other distributed file's exact path, bytes, mode, SHA-256, and origin. The outer archive and this contents manifest receive exact hashes in the separate parent publication receipt and archive `.sha256` sidecar. A digest of an archive is carried outside that same archive. Parent publication should bind the outer artifact URL and digest to its publication commit.

## Publicly reconstructible first-party and dependency origins

The completed origin review verified **980 first-party members** against local Git blobs and modes. Of these, 849 match the publicly verified [Grant base dfad8bfc89778a6d89e38ff481899db552e428b8](https://github.com/crimson-knight/grant/commit/dfad8bfc89778a6d89e38ff481899db552e428b8); 131 belong to the preserved local integration. The included [public-base patch](origin/PUBLIC_BASE_TO_LOCAL_SOURCE.patch), SHA-256 `e0cd75292f6592c4af16ef7efd3f08e80a10e8b1f40c99db1d4fed48245b35ac`, reconstructs all 980 first-party packet members from that base. The [complete member-origin ledger](origin/ARCHIVE_MEMBER_ORIGINS_COMPLETE.json), SHA-256 `248f265c4c64680af17a800b455da25da7b879ed86cf7c7fccbe7960bb282e9d`, and integration history retain exact Git blobs, modes, origins, and reconstruction scope.

The origin review's GitHub lookups found the public base and all five dependency commits. Its exact local integration and maintained baseline refs returned 422 at review time; `origin/PUBLIC_SOURCE_STATUS.json` preserves that observation. The package identifies the maintained local integration and its public-base reconstruction, with public release availability kept as a separate observation.

The frozen dependency commits are Ameba `cdd58b34b0d8a9c785d67183a7a8f07541549e55`, DB `9fff44dd1f61446f9aaffafbb50c4118fe92a3dc`, MySQL `c061324dcef89a200a7a3f86a59b2ebf03f83602`, PG `1f4aefd82440cffd6e70ccb02b7d27bfbfc6d25d`, and SQLite3 `271a1314a6c64e6c3d98942a39bf1b3e8326b190`. All 563 dependency source members and all five directory checksums reproduce the committed lock values. See `origin/LOCAL_GIT_AND_DEPENDENCY_ORIGIN.json` for exact repository URLs, commits, checksums, and license paths. Generated `lib -> ..` aliases and `.shards.info` have explicit derivations in the complete ledger.

## Default-feature benchmark coverage

This is `documented_default_grant` on the preserved maintained integration. Its `src`, `shard.yml`, and `shard.lock` match maintained local baseline `e99cb30951f94c293326aff6c70cc9dcc3225561`. The unchanged rich generator requires the complete `src/grant.cr`, SQLite adapter, and ordinary `Grant::Base` models. Separate experimental overlays retain separate source identities.

The four exact generated sources and behavior manifests are in `workspace/grant_linux_first_build_v100/prepared/`, with their original preparation and dependency rosters. Both model counts retain query-only and query-plus-association cells. The first selected cell is **Linux amd64 / SQLite / 300 models / all queries and associations / debug / cold repetition 1**: **900 create/hydrate/scope operations, 4,800 field checks, and 900 direct/reverse/eager edges**. The 500-model association fixture retains **1,500 operations, 8,000 field checks, and 1,500 edges**. Query-only fixtures retain their declared empty edge roster.

The immutable [full contract](contracts/grant_acceptance_contract.json), SHA-256 `c3c73407ea75f1cc4bccb38b1199beb7958eec355980c4c9697b6da7a8c65619`, retains **144 cells**, both 300/500 counts, both workloads, debug/release, three adapters, two platforms, three cold repetitions, one worker, compiler GREEN, and strict compiler RSS plus audited whole-build memory **below 2,000,000,000 bytes**. Source coverage and package verification leave actual accepted cells at **0/144**.

## Frozen-input audits and future active admission

`audit/` preserves every raw stdout/stderr record, original exit status, tool identity, and measured scope from the completed origin review. The secret scan passed its measured 919-file / 146,744-line foreground scope and all 1,539 staged blobs. Root Grant's library-tier dependency audit returned exit 0 with one medium public-manifest tag observation. Five dependency snapshot audits returned exit 1 with **46 retained findings**: 40 mutable CI-action refs, one missing upstream Ameba lockfile, two Docker tags, and three public driver semver ranges.

Those exact upstream manifests/workflows are **frozen source data** in the inner archive. Active workflow/tool/dependency admission and any future ordinary frozen installation remain separate gates requiring their own exact versions, hashes, and checks. The public record retains the audit failures and their scope. Existing historical gate reports remain verbatim; `PUBLICATION_SCOPE.json` identifies the local wrapper's completed additions and pending parent publication.

## Verify and reconstruct

Use the parent-supplied outer SHA-256 and `PACKAGE_CONTENTS.json` SHA-256 with `tools/verify_publication.py`. Its source-only verification extracts fresh directories, checks every outer file and mode, validates the full inner member ledger and origin rows, preserves the five contained aliases, and reconstructs both tarballs from physically extracted bytes and modes. The separate verification receipt records all digests and its exact Python/zlib provider.

For first-party public reconstruction, obtain the exact public base commit named above, apply `origin/PUBLIC_BASE_TO_LOCAL_SOURCE.patch` with Git's full-index binary patch support, and compare the 980 first-party paths/modes/hashes with `origin/ARCHIVE_MEMBER_ORIGINS_COMPLETE.json`. The included replay receipt records the already completed physical reconstruction. The five pinned public dependency commits and lock checksums supply their corresponding reconstruction inputs. Their actual fresh installation remains pending.

The active Linux first-build wrapper/provider, ordinary Alpha SDK, native/loader projection, runtime corruption and lower-ceiling/OOM controls, exact container cleanup, public-origin readback, and original 144-cell acceptance require separate admitted execution. Parent owns public commit/upload and hosted dispatch.

## Unchanged source-test workspace

The exact v100 preparation scripts/tests/fixtures and exact accepted v102 harness live under their original folder names in `workspace/`. V102's source manifest is `2e77dfb1b0a705d035b925eb31ac9938bdaf6883cf39106b5a972fa4d2843925`; its eight pinned source members and exact `ANCESTOR_SOURCE_ROSTER.json` accompany it. Historical absolute paths inside original receipts remain verbatim provenance data. `ancestry/prepare_first_build.original_v100.py` additionally preserves the exact original helper, SHA-256 `d92a6371fbae122b1ef6f7a43ccef51990a1ab1313118dc28f1ee1d4800d0124`.

`tools/run_source_tests.py` verifies the package contents, creates a fresh workspace whose name contains spaces, extracts the unchanged inner archive as `grant/`, and makes the caller's exact SDK checkout available as `linux_whole_build_ci_v100/checkout`. It preserves original helper ancestry and maps only the fresh test workspace's `grant_linux_first_build_v100/prepare_first_build.py` compatibility path to `portable/prepare_first_build_portable_v101.py`, SHA-256 `4c166386999e7c0b49236e92c01ab00672b63fc80db071f9cf27bd827a658d32`. `PORTABLE_HELPER_COMPATIBILITY.json` records both source identities and this explicit role mapping. The original template/helper/archive stay unchanged.

The wrapper runs the existing **13 v100 + 16 v102 tests in ordinary and optimized Python**, retaining all four exit codes and raw output. Supply the independently declared contents digest, Python executable digest/version, and caller SDK checkout. Compiler/container/native/SSH jobs remain zero in these source cohorts.

The original v100 deterministic-archive test preserves five symlink header modes of `0755`. The named portable helper assigns that accepted canonical header mode to exactly those five contained dependency aliases, while retaining their exact targets and all regular-file modes/bytes. Local metadata models of host alias modes **0755 and 0777 both reproduce the exact accepted d2c90cc3… inner archive**. Changed regular-file bytes or modes change the digest, and a changed alias target refuses. Exact cases and hashes accompany `portable/PORTABLE_METADATA_CONTROL.json`. The wrapper records physical link modes and actual test results; actual Linux source-test execution remains a future hosted qualification.
