#!/usr/bin/env python3
"""Assemble a fresh deterministic publication envelope around accepted source."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import stat
import sys
import tarfile
import zlib

HERE = Path(__file__).resolve().parents[1]
WORK = HERE.parent
ORIGIN = WORK / "grant_linux_source_origin_v100"
PREPARED = WORK / "grant_linux_first_build_v100/prepared"
PREFIX = "grant-first-build-publication-v100"
INNER_SHA = "d2c90cc3110109337c92f567fdf533dadf475b3f468602b8fcb5e2ed21426ff5"
INNER_PATH = "workspace/grant_linux_first_build_v100/prepared/grant-source-and-frozen-dependencies.tar.gz"


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    with path.open("x") as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + "\n")
    path.chmod(0o644)


def canonical_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def tar_kind(member):
    if member.isfile():
        return "file"
    if member.isdir():
        return "directory"
    need(member.issym(), "The preserved inner archive has reviewed member kinds")
    return "symlink"


def build():
    before = json.loads((HERE / "INPUT_IDENTITIES_BEFORE.json").read_text())["files"]
    for row in before:
        path = Path(row["path"])
        need(path.stat().st_size == row["bytes"] and stat.S_IMODE(path.stat().st_mode) == row["mode"]
             and sha(path) == row["sha256"], "An accepted existing input changed: " + str(path))
    inner = PREPARED / "grant-source-and-frozen-dependencies.tar.gz"
    need(inner.stat().st_size == 1626007 and sha(inner) == INNER_SHA, "Exact immutable inner source required")
    gate = json.loads((ORIGIN / "PUBLICATION_GATE.json").read_text())
    need(gate["every_payload_member_origin_verified"] is True and gate["all_five_dependency_checksums_accepted"] is True,
         "The complete accepted source-origin review is required")
    for row in gate["prepared_sidecars"]:
        need(sha(Path(row["path"])) == row["sha256"], "Exact completed origin sidecar required")
    license_path = ORIGIN / "GRANT_LICENSE.txt"
    license_data = license_path.read_bytes()
    need(sha(license_path) == "0b86f20bd913c32e463c1601c7caaf464aeee45d63f94ecf3cd4363c6997014d"
         and hashlib.sha1(b"blob " + str(len(license_data)).encode() + b"\0" + license_data).hexdigest()
         == "c1b32eced1bb58605c55ba7b16d797d2f0473a07", "The exact Grant MIT Git blob accompanies publication")
    payload = HERE / "payload"
    payload.mkdir()
    origins = {}

    def copy(source, relative, role):
        target = payload / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        target.chmod(stat.S_IMODE(source.stat().st_mode))
        need(sha(target) == sha(source), "The distributed file retains exact source bytes")
        origins[relative] = {"role": role, "source_filename": source.name, "source_sha256": sha(source)}

    copy(HERE / "README.md", "README.md", "Publication wrapper and acceptance scope")
    copy(license_path, "LICENSES/GRANT_LICENSE.txt", "Exact Grant MIT copyright and permission notice")
    first = WORK / "grant_linux_first_build_v100"
    first_receipt = first / "SOURCE_IDENTITIES.json"
    for row in json.loads(first_receipt.read_text())["source"]:
        path = Path(row["path"])
        need(sha(path) == row["sha256"] and path.stat().st_size == row["bytes"], "Exact v100 source-test input required")
        copy(path, "workspace/grant_linux_first_build_v100/" + path.relative_to(first).as_posix(),
             "Exact accepted v100 source/preparation/fixture bytes")
    copy(first_receipt, "workspace/grant_linux_first_build_v100/SOURCE_IDENTITIES.json", "Original v100 source receipt")
    copy(first / "prepare_first_build.py", "ancestry/prepare_first_build.original_v100.py", "Exact original preparation helper ancestry")
    portable = HERE / "portable_successor/prepare_first_build_portable_v101.py"
    copy(portable, "portable/prepare_first_build_portable_v101.py", "Fresh portable preparation successor; canonical alias headers")
    copy(HERE / "portable_successor/check_portable_preparation.py", "portable/check_portable_preparation.py", "Portable header-mode and changed-input sensitivity source control")
    copy(HERE / "PORTABLE_METADATA_CONTROL.json", "portable/PORTABLE_METADATA_CONTROL.json", "Executed local metadata-mode compatibility and sensitivity evidence")
    successor = WORK / "grant_linux_first_build_v102"
    need(sha(successor / "SOURCE_PINS.json") == "2e77dfb1b0a705d035b925eb31ac9938bdaf6883cf39106b5a972fa4d2843925",
         "Exact independently accepted v102 harness source required")
    for row in json.loads((successor / "SOURCE_PINS.json").read_text())["files"]:
        path = successor / row["path"]
        need(sha(path) == row["sha256"] and stat.S_IMODE(path.stat().st_mode) == row["mode"], "Exact v102 source member required")
        copy(path, "workspace/grant_linux_first_build_v102/" + row["path"], "Exact accepted v102 harness source")
    for name in ("SOURCE_PINS.json", "ANCESTOR_SOURCE_ROSTER.json", "SOURCE_TESTS.json", "IMPLEMENTATION_RECEIPT.json", "README.md", "FORMULA_SUCCESSOR_NOTE.json"):
        copy(successor / name, "workspace/grant_linux_first_build_v102/" + name, "Exact accepted v102 provenance and scope")
    for name in ("ARCHIVE_MEMBER_ORIGINS_COMPLETE.json", "LOCAL_GIT_AND_DEPENDENCY_ORIGIN.json",
                 "LOCAL_INTEGRATION_HISTORY.json", "PUBLIC_BASE_TO_LOCAL_SOURCE.patch", "PUBLIC_BASE_PATCH_REPLAY.json",
                 "PUBLIC_SOURCE_STATUS.json", "PUBLIC_COMMIT_LOOKUPS.json", "DEFAULT_PROFILE_AND_PUBLIC_ORIGIN.json",
                 "REPORT.md", "PUBLICATION_GATE.json"):
        copy(ORIGIN / name, "origin/" + name, "Verbatim completed source-origin review evidence")
    checks = json.loads((ORIGIN / "PUBLICATION_CHECKS.json").read_text())
    copy(ORIGIN / "PUBLICATION_CHECKS.json", "audit/PUBLICATION_CHECKS.json", "Original audit command, exit, scope, and raw hash records")
    for check in checks["checks"]:
        for channel in ("stdout", "stderr"):
            path = Path(check[channel])
            need(sha(path) == check[channel + "_sha256"], "Every original raw audit stream retains exact bytes")
            copy(path, "audit/" + path.name, "Verbatim " + check["label"] + " " + channel)
    contract = WORK.parent / "atlas-program/grant_acceptance_contract.json"
    need(sha(contract) == "c3c73407ea75f1cc4bccb38b1199beb7958eec355980c4c9697b6da7a8c65619", "The immutable full Grant contract remains authoritative")
    copy(contract, "contracts/grant_acceptance_contract.json", "Immutable full 144-cell Grant contract")
    for name in ("build_publication.py", "verify_publication.py", "run_source_tests.py"):
        copy(HERE / "tools" / name, "tools/" + name, "Publication source/package tooling; actual execution admission remains separate")
    provider = {"python_version": sys.version, "python_executable": str(Path(sys.executable).resolve()),
        "python_executable_sha256": sha(Path(sys.executable).resolve()), "zlib_compile_version": zlib.ZLIB_VERSION,
        "zlib_runtime_version": zlib.ZLIB_RUNTIME_VERSION, "zlib_module": str(Path(zlib.__file__).resolve()),
        "zlib_module_sha256": sha(Path(zlib.__file__).resolve()), "scope": "Observed exact local package-build provider"}
    generated = {
        "PACKAGE_BUILD_PROVIDER.json": provider,
        "audit/FROZEN_INPUT_SCOPE.json": {"scope": checks["scope"], "dependency_audits": gate["dependency_audits"],
            "findings_scope": gate["dependency_snapshot_finding_scope"],
            "frozen_input_status": "Upstream workflow/manifest findings remain verbatim frozen source data",
            "active_workflow_dependency_admission": "separate required future admission boundary",
            "fresh_ordinary_frozen_installation": "pending", "blanket_clean_dependency_claim": False},
        "PUBLICATION_SCOPE.json": {"mission": "memory-budget-experiment", "local_wrapper_additions_prepared": True,
            "immutable_inner_sha256": INNER_SHA, "inner_archive_path": INNER_PATH, "exact_MIT_notice_included": True,
            "complete_member_origin_and_public_base_patch_history_included": True, "raw_audit_failures_and_scope_included": True,
            "parent_public_commit_upload_and_url_binding": "pending", "ordinary_installation_native_projection_actual_build": "pending",
            "actual_compiler_container_native_ssh_jobs": 0, "accepted_target_cells": 0, "required_target_cells": 144,
            "historical_origin_gate": "origin/PUBLICATION_GATE.json retains its original publication-additions-pending observation",
            "active_workflow_dependency_admission": "separate required future admission boundary"},
        "PORTABLE_HELPER_COMPATIBILITY.json": {"original_template_path": "workspace/grant_linux_first_build_v100/prepare_first_build.py",
            "original_ancestry_path": "ancestry/prepare_first_build.original_v100.py", "original_sha256": sha(first / "prepare_first_build.py"),
            "portable_source_path": "portable/prepare_first_build_portable_v101.py", "portable_sha256": sha(portable),
            "fresh_test_workspace_compatibility_path": "grant_linux_first_build_v100/prepare_first_build.py",
            "mapping": "The portable source-check wrapper copies the exact template to a fresh workspace, preserves original helper ancestry, and maps only this helper import path to the named portable successor",
            "canonical_dependency_alias_header_mode": 0o755, "alias_targets": "exact original '..' inside the common pinned lib closure",
            "regular_file_bytes_and_modes": "preserved exactly", "original_v100_workspace_helper_archive": "unchanged",
            "unchanged_behavioral_test_counts": {"v100": 13, "v102": 16}, "actual_Linux_source_test_qualification": "pending-hosted"},
    }
    origin_rows = json.loads((ORIGIN / "ARCHIVE_MEMBER_ORIGINS_COMPLETE.json").read_text())
    by_path = {row["archive_path"]: row for row in origin_rows}
    need(len(by_path) == len(origin_rows) == 1549, "Complete unique physical-payload origin roster required")
    headers = []
    with tarfile.open(inner, "r:gz") as archive:
        members = archive.getmembers()
        need(len({member.name for member in members}) == len(members) == 1749, "The complete exact inner tar roster remains unique")
        for ordinal, member in enumerate(members, 1):
            relative = Path(member.name)
            need(not relative.is_absolute() and ".." not in relative.parts and relative.parts[0] == "grant", "Contained inner source path required")
            kind = tar_kind(member)
            row = {"ordinal": ordinal, "path": member.name, "kind": kind, "mode": member.mode, "bytes": member.size}
            if kind == "directory":
                row["origin"] = "Structural parent directory in the accepted inner archive"
                row["descendant_payload_members"] = sum(path.startswith(member.name + "/") for path in by_path)
            else:
                original = by_path[member.name]
                need(original["origin_verified"] is True and original["mode"] == member.mode and original["kind"] == kind,
                     "The header agrees with its complete member origin")
                row["origin_row_sha256"] = canonical_sha(original)
                if kind == "file":
                    row["sha256"] = hashlib.sha256(archive.extractfile(member).read()).hexdigest()
                    need(row["sha256"] == original["sha256"] and member.size == original["bytes"], "Exact reviewed payload bytes required")
                else:
                    row["target"] = member.linkname
                    need(member.linkname == original["target"], "Exact generated dependency alias target required")
            headers.append(row)
    generated["origin/INNER_TAR_MEMBER_LEDGER.json"] = headers
    for relative, value in generated.items():
        target = payload / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        save(target, value)
        origins[relative] = {"role": "Deterministic publication-envelope metadata", "derivation": "tools/build_publication.py plus exact accepted source-origin inputs"}
    directories = [payload] + sorted(path for path in payload.rglob("*") if path.is_dir())
    for path in directories:
        path.chmod(0o755)
    files = []
    for path in sorted(payload.rglob("*")):
        if path.is_file():
            relative = path.relative_to(payload).as_posix()
            files.append({"path": relative, "bytes": path.stat().st_size, "mode": stat.S_IMODE(path.stat().st_mode),
                          "sha256": sha(path), "origin": origins[relative]})
    contents = {"format": "atlas-grant-first-build-publication-contents-v1", "mission": "memory-budget-experiment",
        "archive_prefix": PREFIX, "manifest_authority": "Every other payload file; this manifest is bound by the external outer-archive and contents digests",
        "files": files, "directories": [{"path": "." if path == payload else path.relative_to(payload).as_posix(),
                                           "mode": 0o755} for path in directories]}
    save(payload / "PACKAGE_CONTENTS.json", contents)
    output = HERE / "grant-linux-first-build-publication-v100.tar.gz"
    with output.open("xb") as stream:
        with gzip.GzipFile(filename="", mode="wb", fileobj=stream, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as archive:
                for path in [payload] + sorted(payload.rglob("*")):
                    need(not path.is_symlink(), "Outer publication members are ordinary files and directories")
                    name = PREFIX if path == payload else PREFIX + "/" + path.relative_to(payload).as_posix()
                    info = tarfile.TarInfo(name)
                    info.mode = stat.S_IMODE(path.stat().st_mode)
                    if path.is_dir():
                        info.type = tarfile.DIRTYPE
                        archive.addfile(info)
                    else:
                        info.size = path.stat().st_size
                        with path.open("rb") as source:
                            archive.addfile(info, source)
    need(sha(payload / INNER_PATH) == INNER_SHA, "The original inner archive remains unchanged")
    for row in before:
        path = Path(row["path"])
        need(sha(path) == row["sha256"] and stat.S_IMODE(path.stat().st_mode) == row["mode"], "Existing artifacts retain bytes and modes")
    result = {"mission": "memory-budget-experiment", "local_package_built": True, "public_publication": "pending-parent",
        "outer_archive": {"filename": output.name, "bytes": output.stat().st_size, "sha256": sha(output)},
        "contents_sha256": sha(payload / "PACKAGE_CONTENTS.json"), "immutable_inner_sha256": INNER_SHA,
        "files": len(files) + 1, "directories": len(directories), "inner_tar_members": len(headers),
        "provider": provider, "existing_inputs_preserved": len(before), "actual_compiler_container_native_ssh_jobs": 0,
        "accepted_target_cells": 0, "required_target_cells": 144}
    save(HERE / "BUILD_RECEIPT.json", result)
    with output.with_suffix(output.suffix + ".sha256").open("x") as stream:
        stream.write(sha(output) + "  " + output.name + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    build()
