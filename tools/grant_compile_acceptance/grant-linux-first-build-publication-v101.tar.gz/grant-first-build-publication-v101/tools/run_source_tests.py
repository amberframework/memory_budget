#!/usr/bin/env python3
"""Run the unchanged source suites through the explicit portable helper mapping."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import shutil
import stat
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE / "tools"))
from verify_publication import INNER_PATH, extract_inner, need, parse, sha, verify_payload


def provider_rows(sdk):
    rows = []
    for folder, expected in (("installation_provenance", "15e27eea749e5d08f7d41256515b078f256c89fed5c49647c09dc99b99406eae"),
                             ("whole_build_memory", "233f9658ccd015e2c9e7c268723963ed3713dbb2fc4a552f65d2b52a13288cfd")):
        manifest = sdk / "tools" / folder / "SOURCE_PINS.json"
        need(sha(manifest) == expected, "Exact caller SDK provider manifest required")
        rows.append({"path": str(manifest), "sha256": expected})
        for row in parse(manifest.read_bytes())["files"]:
            path = manifest.parent / row["path"]
            need(path.resolve() == path and path.stat().st_size == row["bytes"]
                 and stat.S_IMODE(path.stat().st_mode) == row["mode"] and sha(path) == row["sha256"], "Exact caller SDK provider source member required")
            rows.append({"path": str(path), "sha256": sha(path)})
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sdk-checkout", type=Path, required=True)
    parser.add_argument("--contents-sha256", required=True)
    parser.add_argument("--python-sha256", required=True)
    parser.add_argument("--python-version", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    python = Path(sys.executable).resolve()
    need(sha(python) == args.python_sha256 and platform.python_version() == args.python_version,
         "Exact independently declared source-test Python hash and version required")
    verify_payload(HERE, args.contents_sha256)
    sdk = args.sdk_checkout.resolve(strict=True)
    before = provider_rows(sdk)
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    workspace = output / "Grant portable source test workspace with spaces"
    shutil.copytree(HERE / "workspace", workspace)
    mapping = parse((HERE / "PORTABLE_HELPER_COMPATIBILITY.json").read_bytes())
    original = workspace / "grant_linux_first_build_v100/prepare_first_build.py"
    need(sha(original) == mapping["original_sha256"], "The fresh template initially preserves the original helper")
    ancestry = workspace / "ancestry"
    ancestry.mkdir()
    shutil.copyfile(HERE / mapping["original_ancestry_path"], ancestry / "prepare_first_build.original_v100.py")
    shutil.copyfile(HERE / mapping["portable_source_path"], original)
    original.chmod(0o644)
    need(sha(original) == mapping["portable_sha256"], "The explicit compatibility import path maps to the named portable helper")
    members, aliases = extract_inner(HERE / INNER_PATH, workspace,
        parse((HERE / "origin/INNER_TAR_MEMBER_LEDGER.json").read_bytes()),
        parse((HERE / "origin/ARCHIVE_MEMBER_ORIGINS_COMPLETE.json").read_bytes()))
    provider_link = workspace / "linux_whole_build_ci_v100/checkout"
    provider_link.parent.mkdir()
    provider_link.symlink_to(sdk, target_is_directory=True)
    result = {"mission": "memory-budget-experiment", "source_tests_passed": False,
        "scope": "Unchanged v100/v102 behavioral test source with explicit portable preparation-helper compatibility mapping",
        "workspace": str(workspace), "workspace_has_spaces": " " in str(workspace),
        "helper_mapping": mapping, "physical_alias_modes": aliases, "provider_before": before,
        "python": {"path": str(python), "version": platform.python_version(), "sha256": sha(python)},
        "cohorts": [], "actual_compiler_container_native_ssh_jobs": 0, "accepted_target_cells": 0,
        "required_target_cells": 144, "actual_Linux_execution": "pending-hosted", "active_workflow_dependency_admission": "separate future boundary"}
    try:
        environment = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
        for cohort, count, source, pattern in (("v100", 13, "grant_linux_first_build_v100", "test_first_build.py"),
                                               ("v102", 16, "grant_linux_first_build_v102", "test_first_grant_external.py")):
            for mode in ("ordinary", "optimized"):
                label = cohort + "-" + mode
                arguments = [str(python), "-I", "-S", "-B"] + (["-O"] if mode == "optimized" else [])
                arguments += ["-m", "unittest", "discover", "-s", str(workspace / source), "-p", pattern, "-v"]
                stdout, stderr = output / (label + ".stdout.txt"), output / (label + ".stderr.txt")
                started = time.monotonic()
                with stdout.open("xb") as out, stderr.open("xb") as error:
                    completed = subprocess.run(arguments, cwd=workspace, env=environment, stdin=subprocess.DEVNULL,
                        stdout=out, stderr=error, timeout=120, check=False)
                text = stderr.read_text()
                passed = completed.returncode == 0 and ("Ran %d tests" % count) in text and text.endswith("OK\n")
                need(stdout.stat().st_size + stderr.stat().st_size <= 2**20, "Bounded source-test output required")
                result["cohorts"].append({"label": label, "expected_tests": count, "arguments": arguments,
                    "exit_code": completed.returncode, "passed": passed, "elapsed_seconds": time.monotonic() - started,
                    "stdout": {"path": stdout.name, "bytes": stdout.stat().st_size, "sha256": sha(stdout)},
                    "stderr": {"path": stderr.name, "bytes": stderr.stat().st_size, "sha256": sha(stderr)}})
        result["provider_after"] = provider_rows(sdk)
        need(before == result["provider_after"], "Caller SDK provider source retains exact before/after identity")
        verify_payload(HERE, args.contents_sha256)
        result["source_tests_passed"] = len(result["cohorts"]) == 4 and all(row["passed"] for row in result["cohorts"])
    except Exception as error:
        result["error"] = type(error).__name__ + ": " + str(error)
    finally:
        with (output / "SOURCE_TEST_RECEIPT.json").open("x") as stream:
            stream.write(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"source_tests_passed": result["source_tests_passed"], "cohorts": result["cohorts"]}, indent=2))
    return 0 if result["source_tests_passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
