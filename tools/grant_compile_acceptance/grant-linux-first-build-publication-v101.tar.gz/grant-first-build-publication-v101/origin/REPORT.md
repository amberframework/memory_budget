# Grant first-build publication and source-origin gate

Mission: **memory-budget-experiment**. **Source identity is verified; publication additions remain pending.** [PUBLICATION_GATE.json](/Users/crimsonknight/personal_coding_projects/.luna/atlas-work/grant_linux_source_origin_v100/PUBLICATION_GATE.json) keeps the overall gate false until the notice and origin record accompany publication. This review changed no original v100/v101 artifact or public checkout and ran no compiler, behavior, upload or hosted job.

The exact archive remains **1,626,007 bytes**, SHA-256 `d2c90cc3110109337c92f567fdf533dadf475b3f468602b8fcb5e2ed21426ff5`. It was physically extracted into a private review directory. All **1,549 physical payload members** are accounted for: 1,544 regular files and five dependency-directory aliases. The existing reader reproduces the full **1,554-row** inventory and original hash `edeb868d76119f67dacdd829a0113ba0b0637583f0ee2fcbd87078a6cbee9d8a`; the additional five inventory rows represent directory references. Every original payload byte, mode and alias target still matches after the scans.

## Source origins

All **980 first-party members** exactly match Git blobs and modes at local Grant commit `d78418566d90e61d6876a4a2a8abd93bb74f1ba1`. Of these, **849** are unchanged from the publicly verified [base commit dfad8bfc](https://github.com/crimson-knight/grant/commit/dfad8bfc89778a6d89e38ff481899db552e428b8); **131** belong to the preserved local integration. The prepared [full-index binary patch](/Users/crimsonknight/personal_coding_projects/.luna/atlas-work/grant_linux_source_origin_v100/PUBLIC_BASE_TO_LOCAL_SOURCE.patch) is 636,413 bytes, SHA `e0cd75292f6592c4af16ef7efd3f08e80a10e8b1f40c99db1d4fed48245b35ac`. Applying it to a physical public-base extraction reconstructs all 980 packet members exactly. [Replay receipt](/Users/crimsonknight/personal_coding_projects/.luna/atlas-work/grant_linux_source_origin_v100/PUBLIC_BASE_PATCH_REPLAY.json).

Live GitHub lookups returned 422 for exact Grant commits `d7841856` and maintained baseline `e99cb309` in `crimson-knight/grant`. Their local Git identities and ancestry are verified; public availability remains a separate observation. The eventual publication should identify this as the preserved local maintained integration and carry the patch/origin ledger or an accessible exact source ref. [Public lookup results](/Users/crimsonknight/personal_coding_projects/.luna/atlas-work/grant_linux_source_origin_v100/PUBLIC_SOURCE_STATUS.json), [integration history](/Users/crimsonknight/personal_coding_projects/.luna/atlas-work/grant_linux_source_origin_v100/LOCAL_INTEGRATION_HISTORY.json).

| Frozen dependency | Exact public source | Source members | Lock checksum |
| --- | --- | ---: | --- |
| Ameba | [cdd58b34](https://github.com/crystal-ameba/ameba/commit/cdd58b34b0d8a9c785d67183a7a8f07541549e55) | 372 | `18ee1d2c96b1b32707b7e43e37f66b8809ee024927d6ba508f0e56e06a5d9876` |
| DB | [9fff44dd](https://github.com/crystal-lang/crystal-db/commit/9fff44dd1f61446f9aaffafbb50c4118fe92a3dc) | 49 | `4a4dea15c27b985cd9d8c5c545024daafab347b56986252fd24fcc3f18e5c024` |
| MySQL | [c061324d](https://github.com/crimson-knight/crystal-mysql/commit/c061324dcef89a200a7a3f86a59b2ebf03f83602) | 37 | `1566e612cc9021f40db16153491d79191b327576f3dd5facaf1e71b37a574dbc` |
| PG | [1f4aefd8](https://github.com/will/crystal-pg/commit/1f4aefd82440cffd6e70ccb02b7d27bfbfc6d25d) | 80 | `0fcacb5e2d717882de0f809b937224338d171e2a7937c97cb5d5b0306c90eff9` |
| SQLite3 | [271a1314](https://github.com/crystal-lang/crystal-sqlite3/commit/271a1314a6c64e6c3d98942a39bf1b3e8326b190) | 25 | `e62db0abc50b1437630a25594e175cb3e6949c21bcf55cebefdc7d3a8425988d` |

All five public commits were found. All **563 dependency source members** match their exact cached Git blobs/modes, and all five directory checksums independently reproduce the committed lock values using the existing Shards checksum algorithm. Each dependency's license file is present. The five `lib -> ..` aliases match the existing package install layout; `lib/.shards.info` separately matches all five locked repository/version/commit identities. This verifies the supplied frozen bytes and generated metadata. A fresh ordinary frozen installation remains pending.

The [complete member ledger](/Users/crimsonknight/personal_coding_projects/.luna/atlas-work/grant_linux_source_origin_v100/ARCHIVE_MEMBER_ORIGINS_COMPLETE.json) provides a Git blob, pinned dependency origin or explicit generated-input derivation for every physical member. The `src/.DS_Store` file is an unchanged, Git-tracked blob from the public baseline; it is included in the preserved original inventory.

## Default benchmark profile

`src`, `shard.yml` and `shard.lock` are byte-identical between this packet's `d7841856` commit and maintained local baseline `e99cb30951f94c293326aff6c70cc9dcc3225561`. The generator selects full `src/grant.cr`, the SQLite adapter and ordinary `Grant::Base` models. The experiment retains that baseline's complete feature composition. The shared-SELECT and checked-conversion experimental overlays remain separate source identities.

All four generated fixtures reproduce byte for byte from the packet's unchanged generator. The first selected association fixture has **300 models / 4,800 field checks / 900 operations / 900 association edges**; the corresponding 500-model fixture has **8,000 / 1,500 / 1,500**. Query-only cells retain their declared empty association roster. [Fixture and source receipt](/Users/crimsonknight/personal_coding_projects/.luna/atlas-work/grant_linux_source_origin_v100/DEFAULT_PROFILE_AND_PUBLIC_ORIGIN.json). These are source/coverage observations. Actual compile, link, runtime behavior and the strict 300/500-model matrix remain **0/144**.

## Actual publication checks

The unchanged existing global gates ran against private staged metadata indexes over the physical extraction. Their script, Git and Ruby hashes and raw output identities are recorded in [PUBLICATION_CHECKS.json](/Users/crimsonknight/personal_coding_projects/.luna/atlas-work/grant_linux_source_origin_v100/PUBLICATION_CHECKS.json) and the gate receipt.

| Check | Measured scope | Actual result |
| --- | --- | --- |
| `secret-scan-gate sweep` | 919 foreground files / 146,744 lines; all 1,539 unique staged blobs | Exit 0; zero findings within measured scope. [Output](/Users/crimsonknight/personal_coding_projects/.luna/atlas-work/grant_linux_source_origin_v100/Grant-secret.stdout.txt), [coverage](/Users/crimsonknight/personal_coding_projects/.luna/atlas-work/grant_linux_source_origin_v100/Grant-secret.stderr.txt). |
| Grant `dep-pin-audit scan` | One manifest, library tier | Exit 0; one medium public-manifest version-tag observation. The resolved DB commit and content checksum are verified independently. |
| Ameba snapshot audit | 11 manifest/workflow files | Exit 1; 31 critical / 2 high. |
| DB snapshot audit | Two manifest/workflow files | Exit 1; 2 critical. |
| MySQL snapshot audit | Two manifest/workflow files | Exit 1; 3 critical / 1 high. |
| PG snapshot audit | Two manifest/workflow files | Exit 1; 3 critical / 1 high. |
| SQLite3 snapshot audit | Two manifest/workflow files | Exit 1; 2 critical / 1 high. |

The **46 upstream findings** comprise 40 mutable CI-action references, Ameba's missing committed lockfile, two Docker tags and three public driver semver ranges. They remain reported, with their exact immutable package origins. Those upstream automation/manifests are frozen source data in this bundle; the planned first-build workflow uses its independently pinned provider/dispatch inputs. This report establishes frozen-source integrity and preserves the audit failures; it makes no blanket clean-dependency claim. Active workflow/dependency admission and fresh installation retain their normal gates.

## Required publication additions

1. Distribute the exact **Grant MIT notice** with the archive. Its root `LICENSE` is absent from this compiler-input archive. The prepared [GRANT_LICENSE.txt](/Users/crimsonknight/personal_coding_projects/.luna/atlas-work/grant_linux_source_origin_v100/GRANT_LICENSE.txt) is copied from the exact Grant Git blob and supplies the original copyright and permission notice.
2. Publish the complete member-origin ledger and public-base patch/history, or publish an accessible exact Grant source ref. Label `d7841856` as the preserved local maintained integration, with source and behavior acceptance kept distinct. The seven prepared sidecars and exact hashes are listed in the gate receipt.
3. Retain the raw dependency-audit findings and their frozen-input scope in the public review record. Bind the eventual public archive URL to the parent's publication commit and preserve the exact existing archive SHA-256.

The parent can satisfy these additions with publication sidecars while preserving every original v100/v101 byte. Commits, public uploads, actual hosted dispatch, corrected toolchain/native-profile acceptance and full-build acceptance remain parent-owned pending work.
