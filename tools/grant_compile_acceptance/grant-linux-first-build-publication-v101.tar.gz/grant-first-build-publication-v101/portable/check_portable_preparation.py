#!/usr/bin/env python3
"""Model host alias modes and test regular-file/target identity sensitivity."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import tarfile
import tempfile
from unittest import mock

HERE = Path(__file__).resolve().parent
EXPECTED = "d2c90cc3110109337c92f567fdf533dadf475b3f468602b8fcb5e2ed21426ff5"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if sha(args.archive) != EXPECTED:
        raise ValueError("Exact accepted original archive required")
    helper_path = HERE / "prepare_first_build_portable_v101.py"
    spec = importlib.util.spec_from_file_location("portable_preparation_successor", helper_path)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    original_gettarinfo = tarfile.TarFile.gettarinfo
    cases = []
    for label, host_mode, mutation in (("host-alias-mode-0755", 0o755, None), ("host-alias-mode-0777", 0o777, None),
        ("changed-regular-bytes", 0o777, "bytes"), ("changed-regular-mode", 0o777, "mode"),
        ("changed-alias-target", 0o777, "target")):
        with tempfile.TemporaryDirectory(prefix="portable source metadata ") as temporary:
            base = Path(temporary).resolve()
            with tarfile.open(args.archive, "r:gz") as archive:
                for member in archive.getmembers():
                    if Path(member.name).is_absolute() or ".." in Path(member.name).parts:
                        raise ValueError("Contained exact inner members required")
                archive.extractall(base)
            grant = base / "grant"
            if mutation == "bytes":
                with (grant / "shard.yml").open("ab") as stream:
                    stream.write(b"\n# portable metadata sensitivity control\n")
            if mutation == "mode":
                (grant / "shard.yml").chmod(0o600)
            if mutation == "target":
                link = grant / "lib/db/lib"
                link.unlink()
                link.symlink_to("./..")
            def metadata(archive, *arguments, **options):
                info = original_gettarinfo(archive, *arguments, **options)
                if info.issym():
                    info.mode = host_mode
                return info
            output = base / "repeat.tar.gz"
            row = {"case": label, "modeled_host_alias_mode": host_mode}
            try:
                with mock.patch.object(tarfile.TarFile, "gettarinfo", metadata):
                    helper.archive_source(grant, output, [{"path": root} for root in
                        ("src", "spec", "scripts", "performance", "examples", "bench", "lib", "shard.yml", "shard.lock")
                        if (grant / root).exists()])
                row.update(refused=False, archive_sha256=sha(output), accepted_identity=sha(output) == EXPECTED)
            except (ValueError, RuntimeError, OSError) as error:
                row.update(refused=True, accepted_identity=False, error=type(error).__name__ + ": " + str(error))
            expected_identity = mutation is None
            if row["accepted_identity"] is not expected_identity:
                raise ValueError("Portable metadata compatibility/sensitivity differs: " + label)
            cases.append(row)
    result = {"mission": "memory-budget-experiment", "metadata_controls_passed": True,
        "scope": "Host alias-mode metadata models and changed-input sensitivity; actual Linux/compiler/container/native/SSH jobs0",
        "portable_helper_sha256": sha(helper_path), "accepted_original_inner_sha256": EXPECTED,
        "canonical_alias_header_mode": 0o755, "cases": cases}
    with args.output.open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
