#!/usr/bin/env python3
"""Portable preparation successor preserving canonical alias headers and gzip level 9."""
import argparse
import hashlib
import gzip
import importlib
import json
from pathlib import Path
import stat
import subprocess
import sys
import tarfile

GRANT_COMMIT = "d78418566d90e61d6876a4a2a8abd93bb74f1ba1"
PROVIDER_COMMIT = "372bc3379c07c8e75ba92cb6d8a40e57ecbb8bfe"
PROVIDER_PINS = "15e27eea749e5d08f7d41256515b078f256c89fed5c49647c09dc99b99406eae"
PROBE_PINS = "233f9658ccd015e2c9e7c268723963ed3713dbb2fc4a552f65d2b52a13288cfd"


def need(value, message):
    if not value:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def git(root, *args):
    return subprocess.check_output(["git", "-C", str(root), *args], text=True).strip()


def pin_directory(root):
    rows = []
    for path in sorted(root.rglob("*")):
        if ".git" in path.relative_to(root).parts or "__pycache__" in path.relative_to(root).parts:
            continue
        relative = path.relative_to(root).as_posix()
        if path.is_symlink():
            need(path.resolve().is_relative_to(root.parent), "Dependency aliases remain inside the complete pinned dependency closure")
            rows.append({"path": relative, "kind": "symlink", "target": str(path.readlink())})
        elif path.is_file():
            rows.append({"path": relative, "kind": "file", "bytes": path.stat().st_size,
                         "mode": stat.S_IMODE(path.stat().st_mode), "sha256": digest(path)})
    return rows


def archive_source(root, output, inventory):
    """Preserve exactly the existing compiler input roots and package aliases."""
    selected_roots = {row["path"].split("/", 1)[0] for row in inventory}
    with output.open("xb") as target:
        with gzip.GzipFile(filename="", mode="wb", fileobj=target, mtime=0, compresslevel=9) as compressed:
            with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as archive:
                for relative_root in sorted(selected_roots):
                    selected = root / relative_root
                    paths = [selected] + list(sorted(selected.rglob("*"))) if selected.is_dir() else [selected]
                    for path in paths:
                        relative = path.relative_to(root).as_posix()
                        if (".git" in Path(relative).parts or "__pycache__" in Path(relative).parts
                                or relative == "performance/results" or relative.startswith("performance/results/")):
                            continue
                        info = archive.gettarinfo(str(path), arcname="grant/" + relative)
                        if info.issym():
                            expected_aliases = {"lib/" + package + "/lib" for package in ("ameba", "db", "mysql", "pg", "sqlite3")}
                            need(relative in expected_aliases and info.linkname == ".."
                                 and path.resolve(strict=True).is_relative_to((root / "lib").resolve()),
                                 "The accepted dependency aliases retain exact names, targets, and common-root containment")
                            # The accepted archive records 0755 for these five aliases on every host.
                            info.mode = 0o755
                        info.uid = info.gid = 0
                        info.uname = info.gname = ""
                        info.mtime = 0
                        info.pax_headers = {}
                        if info.isfile():
                            with path.open("rb") as stream:
                                archive.addfile(info, stream)
                        else:
                            archive.addfile(info)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--grant-root", type=Path, required=True)
    parser.add_argument("--provider-root", type=Path, required=True)
    parser.add_argument("--program-contract", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    grant, provider = args.grant_root.resolve(), args.provider_root.resolve()
    need(git(grant, "rev-parse", "HEAD") == GRANT_COMMIT, "The exact accepted rich Grant source is required")
    need(git(grant, "status", "--porcelain") == "", "Grant source retains its clean committed state")
    need(git(provider, "rev-parse", "HEAD") == PROVIDER_COMMIT, "The exact reviewed Linux provider source is required")
    need(git(provider, "status", "--porcelain") == "", "Linux provider retains its clean committed state")
    for folder, expected in (("installation_provenance", PROVIDER_PINS), ("whole_build_memory", PROBE_PINS)):
        manifest = provider / "tools" / folder / "SOURCE_PINS.json"
        need(digest(manifest) == expected, "Provider manifest identity differs")
        for row in json.loads(manifest.read_text())["files"]:
            path = manifest.parent / row["path"]
            need(path.is_file() and not path.is_symlink() and path.stat().st_size == row["bytes"]
                 and stat.S_IMODE(path.stat().st_mode) == row["mode"] and digest(path) == row["sha256"],
                 "Complete existing provider source identity differs: " + row["path"])
    sys.path.insert(0, str(grant / "scripts"))
    contract_module = importlib.import_module("compile_acceptance_contract")
    generator = importlib.import_module("generate_compile_acceptance")
    source_verifier = importlib.import_module("verify_compile_acceptance")
    policy = contract_module.parse_json(grant / "performance/compile_acceptance.json")
    contract = contract_module.CompileAcceptanceContract.from_dict(policy)
    original = contract_module.parse_json(args.program_contract)
    need(all(original[key] == value for key, value in policy.items()), "The immutable 144-cell contract remains authoritative")
    need(len(contract.cells()) == 144, "All original target cells remain required")
    args.output.mkdir(parents=True, exist_ok=False)
    source_inventory, source_tree = source_verifier.source_input_inventory(grant)
    save(args.output / "SOURCE_INPUT_ROSTER.json", source_inventory)
    archive_source(grant, args.output / "grant-source-and-frozen-dependencies.tar.gz", source_inventory)
    need(source_verifier.source_input_inventory(grant)[1] == source_tree, "Source retains its identity across archive production")
    dependencies = {}
    for name in ("db", "sqlite3", "pg", "mysql", "ameba"):
        directory = grant / "lib" / name
        need(directory.is_dir() and not directory.is_symlink(), "Actual frozen dependency package required: " + name)
        rows = pin_directory(directory)
        need(rows, "Frozen dependency package source is empty")
        dependencies[name] = {"files": rows, "row_count": len(rows),
            "tree_sha256": hashlib.sha256(json.dumps(rows, sort_keys=True, separators=(",", ":")).encode()).hexdigest()}
    fixtures = []
    for count in (300, 500):
        for workload in generator.WORKLOADS:
            source, manifest = generator.generate_fixture("sqlite", count, workload,
                "../grant/src/grant", "../grant/src/adapter/sqlite")
            path = args.output / ("sqlite-%d-%s.cr" % (count, workload))
            path.write_text(source)
            save(path.with_suffix(".json"), manifest)
            contract_module.verify_behavior(manifest["expected_behavior"], count, workload)
            need(source.count("class AcceptancePerson") == count, "All model declarations remain present")
            fixtures.append({"path": path.name, "sha256": digest(path), "bytes": path.stat().st_size,
                "manifest": path.with_suffix(".json").name, "manifest_sha256": digest(path.with_suffix(".json")),
                "model_count": count, "workload": workload,
                "operations": len(manifest["expected_behavior"]["list_of_operations"]),
                "field_checks": len(manifest["expected_behavior"]["list_of_field_checks"]),
                "association_edges": len(manifest["expected_behavior"]["list_of_association_edges"])})
    save(args.output / "FROZEN_DEPENDENCY_SOURCE_ROSTER.json", dependencies)
    source_rows = []
    for relative in ("scripts/generate_compile_acceptance.py", "scripts/compile_acceptance_contract.py",
                     "scripts/verify_compile_acceptance.py", "performance/compile_acceptance.json", "shard.yml", "shard.lock"):
        path = grant / relative
        source_rows.append({"path": relative, "sha256": digest(path), "bytes": path.stat().st_size})
    save(args.output / "PREPARATION.json", {
        "format": "atlas-grant-first-linux-source-preparation-v1", "mission": "memory-budget-experiment",
        "source_preparation_passed": True, "actual_compiler_jobs": 0, "actual_target_cells_accepted": 0,
        "required_target_cells": [cell.identity for cell in contract.cells()], "required_matrix_size": 144,
        "first_selected_cell": "linux-amd64/sqlite/300/all_model_queries_and_associations/debug/1",
        "first_query_only_neighbor": "linux-amd64/sqlite/300/all_model_queries/debug/1",
        "maximum_exclusive_bytes": 2000000000, "kernel_limit_for_4096_byte_pages": 1999998976,
        "grant_source_commit": GRANT_COMMIT, "source_files": source_rows,
        "source_tree_sha256": source_tree,
        "source_input_roster_sha256": digest(args.output / "SOURCE_INPUT_ROSTER.json"),
        "source_archive": {"path": "grant-source-and-frozen-dependencies.tar.gz",
                           "bytes": (args.output / "grant-source-and-frozen-dependencies.tar.gz").stat().st_size,
                           "sha256": digest(args.output / "grant-source-and-frozen-dependencies.tar.gz")},
        "provider_source_commit": PROVIDER_COMMIT, "provider_pins_sha256": PROVIDER_PINS,
        "whole_build_probe_pins_sha256": PROBE_PINS,
        "frozen_dependency_roster_sha256": digest(args.output / "FROZEN_DEPENDENCY_SOURCE_ROSTER.json"),
        "immutable_program_contract_sha256": digest(args.program_contract), "fixtures": fixtures,
        "compiler_acceptance_state": "pending-hosted-installation-runtime-projection-and-real-build-qualification"})
    print(json.dumps({"source_preparation_passed": True, "fixture_count": len(fixtures),
                      "required_target_cells": 144, "actual_compiler_jobs": 0}))


if __name__ == "__main__":
    main()
